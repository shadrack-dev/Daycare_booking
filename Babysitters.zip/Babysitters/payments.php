<?php 
session_start();
include 'db_connect.php';

// Ensure the user is logged in as a parent
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'parent') {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch parent details
$query_parent = "SELECT p.*, u.fullname, u.email 
                 FROM parents p 
                 JOIN users u ON p.user_id = u.id 
                 WHERE p.user_id = ?";
$stmt_parent = $conn->prepare($query_parent);
$stmt_parent->bind_param("i", $user_id);
$stmt_parent->execute();
$parent_result = $stmt_parent->get_result();
$parent = $parent_result->fetch_assoc();

// Fetch payments safely
$payments_result = null;
$payments_error = "";

// Using sitter_name column
$query_payments = "SELECT id, sitter_name, amount, payment_date, payment_status 
                   FROM payments 
                   WHERE parent_id = ? 
                   ORDER BY payment_date DESC";

try {
    $stmt = $conn->prepare($query_payments);
    if ($stmt) {
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $payments_result = $stmt->get_result();
    } else {
        $payments_error = "Payments table not found or database error.";
    }
} catch (mysqli_sql_exception $e) {
    $payments_error = "Error fetching payments: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Payments | ChaguaSitter</title>
<style>
body { font-family: "Poppins", sans-serif; background: #f2f6f7; margin: 0; color: #333; display: flex; flex-direction: column; min-height: 100vh; }
header { background-color: #2b6777; color: white; padding: 15px 30px; display: flex; justify-content: space-between; align-items: center; }
.nav-right a { color: white; text-decoration: none; margin-left: 20px; font-weight: bold; }
.nav-right a:hover { text-decoration: underline; }
.sidebar { background-color: #52ab98; width: 230px; height: 100%; position: fixed; top: 0; left: 0; padding-top: 80px; display: flex; flex-direction: column; transition: 0.3s; }
.sidebar a { color: white; padding: 15px 20px; text-decoration: none; display: block; }
.sidebar a:hover, .sidebar a.active { background-color: #3f8b79; }
.menu-toggle { display: none; font-size: 24px; background: none; border: none; color: white; cursor: pointer; }
.main-content { margin-left: 230px; padding: 40px; flex: 1; }
@media (max-width: 768px) { .sidebar { left: -230px; } .sidebar.active { left: 0; } .menu-toggle { display: block; } .main-content { margin-left: 0; padding: 20px; } }
h3 { color: #2b6777; border-bottom: 2px solid #52ab98; padding-bottom: 5px; }
table { width: 100%; border-collapse: collapse; margin-top: 20px; background: white; border-radius: 10px; overflow: hidden; box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
th, td { text-align: left; padding: 12px 15px; border-bottom: 1px solid #ddd; }
th { background-color: #52ab98; color: white; }
tr:hover { background-color: #f1f1f1; }
.status-paid { color: green; font-weight: bold; }
.status-pending { color: orange; font-weight: bold; }
.status-failed { color: red; font-weight: bold; }
footer { background-color: #2b6777; color: white; text-align: center; padding: 15px; margin-top: auto; }
.error-msg { color: red; margin-top: 15px; font-weight: bold; }
</style>
</head>
<body>

<header>
  <div style="display: flex; align-items: center; gap: 15px;">
    <button class="menu-toggle" onclick="toggleMenu()">☰</button>
    <h2>ChaguaSitter | Payments</h2>
  </div>
  <div class="nav-right">
    <a href="profile.php">Profile</a>
    <a href="logout.php">Logout</a>
  </div>
</header>

<div class="sidebar" id="sidebar">
  <a href="parent_dashboard.php">🏠 Dashboard</a>
  <a href="explore_sitters.php">🧒 Explore Sitters</a>
  <a href="bookings.php">📅 My Bookings</a>
  <a href="messages.php">💬 Messages</a>
  <a href="payments.php" class="active">💰 Payments</a>
</div>

<div class="main-content">
  <h3>Payment History</h3>

  <?php if ($payments_error): ?>
      <p class="error-msg"><?php echo htmlspecialchars($payments_error); ?></p>
  <?php elseif ($payments_result && $payments_result->num_rows > 0): ?>
      <table>
        <tr>
          <th>#</th>
          <th>Sitter Name</th>
          <th>Amount (KSh)</th>
          <th>Date</th>
          <th>Status</th>
        </tr>
        <?php while ($row = $payments_result->fetch_assoc()): ?>
        <tr>
          <td><?php echo $row['id']; ?></td>
          <td><?php echo htmlspecialchars($row['sitter_name']); ?></td>
          <td><?php echo number_format($row['amount'], 2); ?></td>
          <td><?php echo date('d M Y', strtotime($row['payment_date'])); ?></td>
          <td class="status-<?php echo strtolower($row['payment_status']); ?>">
            <?php echo ucfirst($row['payment_status']); ?>
          </td>
        </tr>
        <?php endwhile; ?>
      </table>
  <?php else: ?>
      <p>No payments found for your account.</p>
  <?php endif; ?>
</div>

<footer>
  <p>© <?php echo date("Y"); ?> ChaguaSitter. All Rights Reserved.</p>
</footer>

<script>
function toggleMenu() {
  document.getElementById('sidebar').classList.toggle('active');
}
</script>
<script src="script.js"></script>
</body>
</html>
