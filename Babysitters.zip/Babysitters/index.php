 <?php 
session_start();
include 'db_connect.php'; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Daycare | Find Trusted Babysitters</title>
  <style>
    * { box-sizing: border-box; }

    body {
      margin: 0;
      font-family: "Poppins", sans-serif;
      background-color: #f8f9fa;
      color: #333;
    }

    a { text-decoration: none; color: inherit; }

    header {
      background-color: #ff6f00;
      color: #fff;
      padding: 15px 0;
      text-align: center;
    }

    header h1 {
      margin: 0;
      font-size: 2em;
      letter-spacing: 1px;
    }

    nav { margin-top: 10px; }

    nav a {
      color: white;
      margin: 0 12px;
      font-weight: 600;
      transition: color 0.3s;
    }

    nav a:hover { color: #ffe0b2; }

    /* Hero Section */
    .hero {
      background: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)),
                  url('data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxITEhUTExMVFRUVFRUVFRUVFRUXFRUVFRcXFxUVFxUYHSggGBolHRUVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGxAQGy0lICUtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIALcBEwMBEQACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAAEBQIDBgcBAAj/xAA4EAABAwIEAwUHAgcBAQEAAAABAAIRAwQFEiExBkFREyJhcZEUMlKBobHBFiMHFUJi0eHwcvGi/8QAGwEAAgMBAQEAAAAAAAAAAAAAAwQBAgUABgf/xAA4EQACAgEDAgMGBAQHAQEBAAAAAQIDEQQSIRMxBUFRFCIyYXGBkaGxwQbR8PEVIzNCUmLhcqI0/9oADAMBAAIRAxEAPwDZ21SCAd9/NIbsPDDxWeUNHnRUt+EvDuIr7mvPWv3masOxZwy0Z3T1C2vCF7rM/XvlDLiPXJ80/q+yFdP3Yhu2d1J4GhI1veVJF4gOLNXVsifYRsbqU4nwKM+cxSQVtauOwdC4b9wLIu+I0a+xdjeyHD4gj7CvDrcEp5zwjLufJoKOHtI2VeoAyB4hhbY2Vla0Tkzj8Kl2iYVvBbJf+niQo6yO3Cu+wh7FdWJlsix1IhXySfa9F2TgeoqMuinKhljrXB4/bb5IC7h/IYcQe4fJWZyE/B9PfzWnpvhMy9++b2g3RMFC9oXEkaxAVWSgYXTVQueG5aowcR9obK7BxP2tq58EZB69wIJ5KHPCyDZk7q8qlxLW6TosK3W6je9seC2I+oJgtQudJ1RIycrMs03FKPBqXe6mrPhBQ7iS85rz1nxs1IdinCroMc6eZWt4dYoJpierhuDru57QjoE7bZuYtXDagS9HdQy6EjB3kOYWIBjAUQ7nT7CKn7xTi7CsidQKxUGBUPsSdA4bPcCybe4/DsEYzsqQ7l32FmHVQD801YuDLuXJpbS4EJfIDB5eOkKyOF9o0Zldtoke0aAhQpHCzFrQQUWMuScmRrWMuKejyidxJ2F6bKGduFt5h0KO5dSAH2ZCrJBFI6bwo2KbfJLruMeQRxLeMpsOY76ASJ89Tt48lbGSOwj4Wxcdo1jWOcHEguaDAMTzjSPuOq0KHhYM+6KznJ0ihsmgZeAoJBMT90+Sk4xNSu/4imFGJJUy9eD7xV+nEgKNdx1kqiisnE7R5LtSY3SGqsW7ajksjWiSRJ2/CBHtlnPgUV7s5jAEctFh262W97FwXVfHItwBsQmq175pT7GnqHupqz4QUO4lujuvP2fEzUh2FIEvTmlWQNw3oiAFopYE85I33uqzIQlp+8hTCxAcZ2UQ7kT7CG3HeKcQtIuqtVioBC4k3nDb+4FkW/EP19gvGHaKlfcIzIVsQyE+af25QhOOWN8BxMvPNLWV4ATWDSOdooigQDb1wHwryjwcjQ2taQhLucC4m7RFj3IM80d5aMOxIU4aLmionxS5YyC7b7DmVWPcJCOUJ3YzTB1bpsCJOsbHQD0JV5LIVQHFpxxSpsaGtJc5o30DTzBnyPXkgOth4tIzl3jtS6fAaCBGcl0h2UkAuJEtJc7YRGkIigokOWS624gfReCKgaNA5jRma0gie5IE6RHiUaD2gJxTNrZfxHoscA5xezOGuc1joaCJzagExDhlAnTWTux1EL9ORsMH4qtrglrHOBGnfaWfDl96PeDgR1HzVlJPsc+O4xxES0+SsiGY426OpFtpRVtFfedglTZpCrJ+ZGAiiQD5pFwTbbLBt3cAMgc9FleIahQq2x7vg6EcyMxc3cOI6Lz7bTDNMe4dhTmr0EK2nkYcuBnUtzCLYm0Vg8MV3GGPKyZaKcnnI8r4pFNtgb5JJT2m07guQF1yl2DzhrtEy4AFIquMKc4RK7YSmBM4edMyqOtssp4B77hZz/6iujW0Q55AaXA5BnOdfJGSYFrJYeCT8Z+ink7BWeBP7iu5O2jzDeHuzESUpPT7nkZjZgtvMDLxElVjpcFncI6/AwcdymFFoC3kOwvhJtLYlVlVu7gpRyNjg+m5UKkp0gM8NjNMn1U9Isq0MqGGhvVU9nI6aPq+FhyuqUjumihmBM6I8eC3TRYcHb0XMjpIz/FGE21NnaPDQ5oJZJiXCS1u/Mn6qnnwEjDCOWYlfmMnYtaXGQZOXY5SGnfbz0Rox+ZD4FbqugjURGnPTUkjSNArpFfoRt759OQHHvgZhoJgGNOgl209OalxTI3YKq1RznRnyiBA1Bg7zG43310UpYOfJK2uXt3jVrm6ge74zz0GvgueCEPMJxfsnMcSTke14ILZzbOMOBEwBBIMQFTO1l3HcjsPDmMGpTp/u06hLAaoY+crnHMe5ygENEAR06d1yiowPBbt8F3WZfYe+zN8F3WZ2xEfZGeCjrSJ2ol7IzwVHJtYOUUei0Z4IHRi3lk4+RE2NPwU9KJ32Km4rTO0KVYi7rZP+ZM8FO9EbGffzFvgu3o7Yz3+YNU9RHbGSp3oJgLuoRsKr3FWU4zECVWVyj3LRqbAzxJR+IfRV9oiT0ZEDxRR+Jv0U9eJ3RkR/VVH4m+oXddE9CRIcTUj/UFHtCO6LJjH2HmF3XR3SZIY43qu66I6R4cbao66J6TPP50FHXRPRPv5yFHXRPRPWYtJhd1zukGOuCGyp6pHTM1f8XNpuLTOngh+0hFQBO47b0Pop6zO6JD9eDofRd1md0SX61nkV3VZ3RMhxPiL6ur6hcJkMOwB5f8AdEWuTZWcEhTgWAOuqsEkU2++RqZkkMaTt5+Kvbf048dytVO989jffpahAHZgBo0HL59Un1rPUb6UPQW4pwzRfs3KeRED6okNRJFJURZicXwnsHnmDvqZ7uuwHjvPNO1271yJ2VbXwAVLLuy1xbEETBjYkHroZkK+/ko4cC9tbIJmCfR089v+Cu1kongf4Bi9SmQ5rnH/AMuI2IOuXyA+qWsiHg8nTKPE9R9u2sIJnKeWsbEdUjbZKDwMwrUgUcUV+gVFdIv0Ynp4muOg+qnqzO6UT5vE1weQ+q7qzO6MS0cQ3B6fVd1ZndGJaMauOo+qjqzO6MRvhuE6BM1V5XICywZtwsJjpoD1GWNwwLukR1GWjDgu6Z3ULraxAMqVWQ5mT44pSW/NZWt4aH9KY59t4JJSY4UeySUaLyUkgijhZVio2s8KKJFNg5TwO7bCkzGoBKwNp4Wr9Ip1C4YaOi7pEdQ9/lvgo6RPULG4eo6ZPULKVjBU9MjeG3DO4ulHCIi+TmOOUJquSeOR2PYWttJREyGEU8K8FbJXIytsH8FZRyUlLAi4wsuxc128t2I6GdD/ANsEzSvIBZLzN/wrgzaVBjdJgFx6uOpPrKBjfLcxjOxbRvWtwr9Mqpie6tghuGAqkYPiy3kzJzCYjpEf7R6ZYA3RzyYS6qVWjKToMx03y8wOo39fJOxSfIjJtcHz7bunK6dMwPIROzgNu9rqNuSndhkY4I2FQtI1A26bE7+P/BVmiYvB1HCsTbVt2USwsezqIJAPdO3SP9wsrUV4eTQpkF21jKDFBZSGFPCwUwoAXMvp4OOiuqijtCaeEBW6SK9UIGFjou6KO6rHlkzRGpA2BoamADJhqk4llXHHsKDjE8YCXN+axdd3NTS9jNPpJMaPbWgJV4ESHNC3CKkBbGdtRCarQCYzoUwm4i8gprFcoTyLsHHuVRgk+yqMHHoapOK7z3UKzsXr7nOsXH7jkg+4/HsD2lPVcSxzRohXiCYytqYTMAEhDxrgz63Zmm0lzSCSfdDQZMlFUkmVXPA4wLEmk9mKrKjm6HKdiN5by2PohLMccB2s55JY1iIpS6pWFNnMkTCsm28EYW3JQLntGZqb21WnWQIMdWnYqZomL8xZitrmbMajUcvMIKeGEayc64jotDuo13EgdSTOnoU7Q+BK9c8CaiZpZWk/1Ea5QJAkCB5o0u+QK7YBLUnTeZI9BJ0AnYfVWkisTT8MYy5lTKdQ8x1JPLX5pG+tNZQ3TPDwdPsgkojMhrSCYiwDCaQRUyjQUwK2ShaApILrXZdV2OsC2phAWTCkgkuOPCVB2DF8VHvj5rE1r95GppuxnyEmNFlqNVeBEhxQR4gJDGgmYAZDGimoi8ghquVJqSD0KDj5QSfLjim9PdQrOwSvuc1xqtFRyR8x+PYHsrnVW2snGR/aiodmo0aLH2QOW1d2GtrOZ7whG6c490D2KXZl3t4Pd66eq5ywiOg0UYTglGi8vp0ocRBcQCQJDtCdRJA9FPXm4bfIh0w37/MLvLRlbUjNBnQkOGkbgz/vVVjZh5RZwWNrPWYbSYC5rMp5nWTz16/NTObnyyIwUOELr54gylpDEUc6urAvfUcSGsYdd5cCfdA5zpvzTVdm1JALK9zbEWL4T2OUAAQA8Tq06b8559UxXZuFbK9vYUUCSZGhBGu8nQfIf4RZPAKPJuuEMNOY1XNDmuaCHEt0M/CDoftAWdqZ+Q7THzN1ZpaIWQzpuR0wTCKZRUwbQUwqSpZKtkrgMo04R414BSnkvV8FclfbqjkX2nvtCjedsPm1wVHUTJ2YMXxhdNY4Fx6rK1UHOXA/Q1FcnPMT4ngwzZFq0PHvFbNVh+6V4bxWQ4Z9iiS0aS90pHVZ7nQMIxFlUAtKV2OLww2U1lD23CPBMDJjCimYgWENVyhJcQeyuJPVxJ8uIBb891L2Bq+5ybiOr+65Kw7jn+0owCr39dpTcEskRfodJsL6kGiSAtStxwLWU2N9gLGsVpRAIPkrTnHAxpdNZnOBJhWItFZhJ0nntJEBJXNbHg0rqW63g07cQY4uaajmEkjumDAHL5TqloSyZc4NeQTRdRZq1xLgIl1RzzpyJcSUbEO/mB9/t5FV/iALdEvOzPAeFeDP31Tuhx6IPcKgC2su1BALQMzHPJEkDUyAP/MfNFjxyykjE/xExWnnp02gOqNaRUA0aySSBpz1OnIR4y9poN5l5COoml7pnrFnukA66GQPICOe/wBkSYKB1XBqpbQDCwtLTzgTO+k6ajmAse7vk0a+w1snqsSZDa1ZmTdde5C854DaVujqkC7QttsrdFlOqiXYrugR1UTbdhMZKbSFe8ACiTwi8a8gLrwJOU1kZ6bIVb0dVSdiwTGHJ7aXOpM8kCFmWXlHCOTceYo6rcObPdbonaorG4WnLnBj6gLnBoR+yyweMvAdRwwkEoMrMBlUxzwvcvt6zZJyOIHkhvbNk7ZQR2u0LS0HqE0oIA5MKpwrKCKOTC2MCtsRRyZMsC5wR25gtQhBlALFlDq0IEuA0Vk89oQt5faVXr+4qTfBeC5OS8SH916Xr+IZfYGwZ0FNomhZkM7yodEddjapisARUjJ7ChkG1w26JtzXpktrU6b2EtME7feGlVp9yXB5/VUJW7JLh8l1Hh2pUY72q6uKtRwGb9xwY2CXANaIAid9z5aJ7amuWZ3CeYLH3LKlm2nSa0EmBEuMuPm7msq9LdwOVyeBDi9XSJVYQydKeDMYtWLGlzXFpyxLXEGOkjkmIw8gM5+ZzmjTJ7xkyZJOus8+u/XVaOcGbjkf4dZOhuaQ15ytLQJzRpBGx215Ql5yQeEX3Z1rE2ltKmD70CT1Mameaxp9zRgU4a7RWR0h1YXEaJ3TTw8Cl0eMhlK9Id4LQQjJ8jZl2CFJGSBuguwdkDa1Vr5Y5d7iyV3OoU3wwgen1CbM/iN1l5rGsfJqwaYuqYltqlbZtIIoIeYZWlhP9qrp5ZBWo5TfUS+4q8+8VuQeIIztrcmVYLZfuOkbK0nlFq1hmpt7FvZkTqlJ9xyHYR3mmnMFVink6eMHWeH6pNBn/kLVhBbTEnqOWgunUdK5pIhXJjJj3QqbkE5Z864cFbOSAGteEHUoE5chogFXEBO6RuswOVRyW0LiUup5CuIXdvGQ6q8nwRFcnKOInjtXaodUXkNJrAHhlZs7pxRZNEluHDyDsjrsblfYqqU1bAVMHKgvwNsAvuyqCfcfDXjlB5/JRt8xLWU9SGV3XKOiObULYL+4B1J28yrOyTXc857qfC5EGP3zWANJ1iYS6g5vKLuxQ7mQuazqgLgcrB/WefXKOfnsmMRjx5gdzlz5HttwxVrtD3F1Np92WFz3Drl2aD1PontNoZWe9J4Rk63xiuh7K05S/JP59/0Kr3ghgaQMweQ7XKWhzjtLY08wtC/w+uUM1vDS+z/P8zE0/j2ojdi+OYt/RrPmn2aXoH8FWTe40tBy66iYcOfmvK2SecntsLGB9xdUjKlXyw8ADDD3ZV0iJMnb4i3tA1O1VNSTFrZrA9dC0UjNlIIpGArpFHIkagVsA9wW3KsuFzXJsXR3rDPKlJhCtZe5C0NOovgV3GD0n7hJyjkci2ij9P0fhQ5UphY2MturZtOi7KOSiNSj2O3ts5vb0x2mf4t0437uCFFJ5Dq1uWy5jd+i6Es9zpRx2K8Lp1HBznSOiixx8ialJ9xBdEl4GurgPUoiS2ZBzbzg7VgFJjaLRPIKIXtLDM2ek5GQa2ZlS7mdDTYZd2zYQ3YxtVg1VwPNHhbwUdfIpvLXMdygWybfASNYvOGAS4uKUnBy7jUHgQYhidUNcaX9M6+SLTQv9xE5tr3TE3fG126WlwCeengI9aYsp131HS50yu2xj2JUpS7ld3UdTOhKLFpoo8p5NBwpiRqOyuQbfd5NnQ6542yNRimHVSAKLCZ5kKIyyssnUa6ecQEdSwuKZ77SFzlEUWpvznIywKj21VtM85Lo+ECTHjy+aLp63bYoB9R437Pp5WSWWu3zZsMYxIWtGS7K1oE7HchrWtnd0kfda9vh+nUXN5SXo+54inxrXWWxqSjJyfLa7Zflhrt9GKKvDpruz1HvM6kE90/5HhssWqrUWLEY8fh+p6W/U6SlvfJZ+uX+C/kPrDh9kguAIbsCJA8Y28lqUaFV+9N5fp5f+mHqfFJ3+5StsfXzx+36/QdkRttzPMp7v3MrG34QKuwxqZ23+oRYi0845/MTYXh2Ss5zRAJnKeRJ68wd/pyXmvFNL0LMr4X2+vmv3PW+D672mnbL4o8P6eT/AK8yPFFi+oW5eSx88m5F8A1lh1RrII5I0GslJC6hgNVtYPjSVpRujjAlKts0rqLzyRlfEWlRI+d2m0K6vgDdE2WQ7op68CvQn6Cq07UgEVCViRZtSQaGVh/UUdVyxnAHfHOMng7b4lQsSca3xLiQiwY90teZBC44x3E9gKFQAbHX5roSzwG9CqjibWtgqMBeC196GsJ0gqemdvMsbppcfPRc4tIjcmbbCsTrFoAhCXAOSG9O9rdFfkHhBDLip0U8kE/aKnRTycfdu/oo5OE/FGI1KdEwNTopisvk6TwsoSXf7VlJ95wk+ZTVcd0ik5bKzmL7dxdPUppxwJJ5G9vhz2wUvLkZjHBO/s84jmui8Ezjk2H8IsBBL3vE5TDV0luZEOFk6623A5BX6Z28U4zYNeNQl7Ksch65CjAcIayo94HINHz1P4Wj4VD4pv6GH47LKhWvr+yHzaIMSAYnUgGD4dFrtmBGHBXlDnaDQfUq2cLkFhSlwuxfUdlB8PvBP4VEssPKSimfVB9gpR0ih6sCYturksc0wI1B+8fMA/MBVu00dRVKtvv+vr9gdWsnpbo2xXbv816ff9cPyBsdxYUi0xM9F4G3dCbg+64PpNLjZFTi+Gsr7igcWN+E+ilNl3EmOLGfC70VuoyNhJvFzPhd6KVbIjpom3i5h/pPoVPWZHTRZ+qWdD6LutI7poA4bxMZQTtC0tBpHZPJXWzUdPuRpBiLHCZC9J7FhYaPDy8R97KYI7GqYO4WPrdFOt5wbug1sL4ZyVPx2ntISCrY/wBaPqX2uOU26khCl7rwPabTu98GU41xVtQgt5KKoNzyxvUaKymvc0Z6xIqOAKYcdvIlu3LA6xB1JrI5wi74sp02jIEDNI66INkjQ0WildyP8Exkse0O2KBs4yA1NTqm4s6bZBrmhw5qUJsNZRCsipLsApOPRQC44X43h7XsgqGSueDn38RrtraIptOugATVLK3r3TL4FhNWo5pdoN0SduEBrpbeTR3VplcAg8yQy8RZbRsWmUGTaYZJNGv4EAo0yCR3nEgeaZq55F5rHBs7i5AEo+QKiLLi6DhIMoU8oNBJnmHkEEjqfwFo6HHSf1MDxf8A10vRfzCakxA3OieXfLMieduF5nlMBunT79VLyyIJR4XkB3NaGjxzfaPyixjliltm2K+eQwGQELsxtcrJW4b+Sko0Lr6lmaR6eYMj7K6lteRecN8XEzWJHPTpno2PTT7QvF/xFV0te2u0kn+z/Q9t/DN/V0CT7xbj+HK/JpAdlhoOrlhWahpYRvYGdHCWHklJamSOLXYRTGkKq1M35kBNHA6ZEwEKWrmiCRwin0Cj2mZIJw/gwpiHAagL6Bp91UsoQdkba8DpuFs5ALUWtkY9vhlUnnCALnhum4kwJPRXeoc1yAjpI1cRWDN8QYMygAWjcrM1GU8jmnoW7IluK3dlZ7jl8m5VY63mJTU/cp+I2RIHsa9uooWfNCoVDTMhGa3I8ZqaZUWuLB73Fnu0hDVeAbtbJ4RRc7dVklk9H4FPMHkNvLUgSqeZHjNG5dRHQ+BsR7SkATqNEN8M84zWsKkpglmXZOwetcuydgXYjX3XBIo4Xx/ek3Ag7GfRO6ePDFtTLDRr+FLUvY189EOckuA0ItrJqBY03GDCHCxrgvKCfcuuLBjG8oAUSWWEjwh3hNozs2ugeaZrWIgbMNhrgXGOSnnJHu4Kri2a0aCF0i0UvIhhh0+ZWhoP9H7s874z/wD0r/5X6sLqOA+wT0VkyJtR5Kid/JEBPgDvx+209J+qLV8bE9Uv8pMJw+pmpjyA9NPwhWRxMZ0099Sa/ryJuMbKO4RvHYFeFZ8gnw0Ze+pZG5fhe/0OUj6Lyv8AFD3WUv8A6v8AU9R/Cq213L/sv0LLSnnbovG2PbLk9Sxjh9sQd5QL7Iy7LBUIq2ZLpUUXxrfvLJD7BlCkQ1AvsjOzclhEAT7RxO5Ro21pcoksK+lS7mXRHbDB4HuHkoWGTK3B6blOVQ4M3UWJvgxPG95L2tnxSusWMIY0TymzMVHyFns04hWE6j6KOx6vwmzdpsehZdYYHbKVItrtFDUrPZgBwR0ydlO8xX4PavNDPDbcNEIec8m1odL7PDBXiLo0XYyF1UN9LDeA7qK4pzAdt5hd090kjxVj2I683D9JlMey/MU9oPRhxUey/Mn2grurMtaTKrLTYWclo35eDM4i/u+aWHEYDj3gz9rtmau38x0TdMnF89hS6O7lAHA/EmVnYu0cNFN1XOUE09nG1m5tM7yMvqgKIz2Qq40xQsHZh3LVXiijl5Gx4UxHPZ06g5NEo8ewKTyHfztrnAMBM+B/IV38imyS5aCb0GNeipJBIyRThZ0PmU/oP9LHzZ5/xj/XT/6r9WXvMytFIxJPOSuu6B6K0UDseEU1xLQPAK8OHkFat0FEGtrxlEv7RwZTDM+ZxgAyGn1kaKblmKl9imie2cq/LGf2Af1paO0pdrW5ft0nAetTKFnz1dUHhs3a/DNRZHKSSfq1+2WTdjjTE0aw8xS/D1T/ABGld8lpeB6l9nH8f/BTjV7TqNlhMj3gWkHUaeB2O3gvPeOW13SrlB57r9De8D0lumVkLY4zhp5XPkW4VVy0Z8F5O+O6zBtsnhWJOc+C0hRfRGMc5IwahrxzWW0yjB8Su8jJGvkiU175YJSFLcaPwn0T3sLJwGl6+kSra7nmbtYl2LDcNywVWFLcivtUZRICiCJR1PazPnY2znnFrP346BKaqzfI2fDv9PImcyAkpGpEIwWuBIKnbnk9R4RBqhv5jxjgVXBotNFoZOi4o5Y5F1WvldDRJCDhtmRqdfKLwge/YXakbKE3Fl9LruonCQpoXZpVGvb7zHBw+XJMxfmjz2phy4n6E4cxVlegx4I1aCn4yysmPjHDGmcKxAqx25AbA3OiBfPEQ+njmZicfrZGz0hZ2DSQnv8AiYVaYYG6Rqm6pLctxfTwhu94z9pgtMuLgIK2YRhJGwtLVjODXcPsexrp+SzdVSq5ZRm6qnY+DB8RtfUrkHql4RcuwrGEpPCRuf4d1zTBoO906j8hH6U4rLL2aWcY7zedg1gnQALhSU5MU4hiTToCqvkhcEsKfLT5/haGh4i18/2MLxd5si/l+4cGT66p/Jjbcldfcq0QdnOSuo0kb7qy4ZSabQlx2kDAI021TNPKM3VtwmtoLg9rTa2GtA1P11/K874vSq7ty7Nf3Pc/w5qnfpdsnzF4+3dfy+wfdsBCyJ9j0UDKX+jiBzH/AH5SOohmOfRjEHyaPC6YFIT0Xm72+pwWYdaMp7iJQLHPzIYqxCrX7TujupqmNOznuTwPbSnmpjPvCQsltn7pU+FrT8Porde31IA67SCvsFklJHium33KqrSVTbtWSFFpl9rUJOVAs4W45UtvBz7ih59pcDyhZ7eXk3dJDZXgT3VXQoUx+BLA6ObfZWTwj1/hj26dGgNWmwKBvEmD079znjQhuuqiS4FdVJRre3uTtqbe0JlAkuDy7m28M+xy5ApwN1SK55O3OPKMhSoucSSUyppcC025PJ0H+G2JuZNKdAdNeqNVMTtrWTovtp6pjcA2ijELqXiSlb3yhvTxSRmuKastiUBdxuJjhVDGxzV1EIlhDjBnkgE84W1p37pt6bmrk19l7iS18ucGdrX7xi7tk3J81Gg7kaT4hwx2UAgxHNa2xPhjd99VUc2Pg1ODMNzS7zj0WZdBKbSPOW3V2PdWsIOZglKmC46x1Q8AdzFmC37alas1vujLH/6H4C0dJXKKbfmYnidkZyil5D1hTZmJlVQb+JV0Blzk8eIEqVyzpcLJnMRqZnwNY+6erWImFqJ7p8BBo5I8Rr57/ZZfidXXpbXePP28/wCZ6DwC/wBk1ShLtNYf18v3X3LqjZavKM+iIx2Ku/djpE/MwhSjmDLt4aNPVs3Oo5WmDG4Xk42xjblhmR4ewqoxxzOJHRTq9TCcfdXJVtGm9mb0WZvYPeB4vReWwzRH004qWZFoMSey1+pWlv0xfJqbo0na6L3Er8NGBGlNCdtVodErQlcnWL1U4s5Pn1WtcCEp1FKOGGurcZpo5txdUBunEdAgRWBqt8GduXE6BVkg0ZDLCrgsbBCozf02uhXWosOq1WuGg1VXnyCz8VilwfOc4jkFxnW62yxYK31cvPVUkxSPzFd5dknUqEskTeACrfcgiRrAuaQ94NvC2rruUaMcC9ksnS2XhjYouUBwyu7IeOh6qsophYScTMYthzzu+Ql5yURuttgmF4Y0P7wlJ2XylwhtIatogbCAF6HRp9JNmvp37mB1bO7nySWtfvmZrH75j69M9uXHZNeG6W2fvRXBlajxWrR/E+Qms/ORlOg5LZnmuDjZH7nnLdTLWX9RWfY22C4pb0aIzPAMajmsLbJvODY3wjFciXHuJH1wWUu6zmToT/gJzTaeLl77ENXqZ7f8tfiVcD1P3ao/sb9HFallXTSX5GI7Oo8vubcf7QDitXAguLV8rN9ToESmOZC+st2V8dxdhNtJzH5eaYunhYRn6OndLc/sWYrVAIbzn08/ohwaUXJ9sDFybtjXH4m1j5c8Hod3PkvEN5yz6sljgy17SmqOrnNHq4JeyWKpfR/oEa7DnEcfbRcGQTpyC8xVonanIK2P8MvQ+mHjaJWfdU4T2lGsi39VUu0yTsYmDE+aa/w6ezcTsWB5WumimXu2AlIRrbntQNR5wITxVR8fQ/4T/wDh1gXaKqVN7mgh0giQRK9XufmK7UWDDqxEw6OuqsrZdslMQyEWmFOe0k1Mp5AoUrrlJKEW15s6WzzMbj+D13ONRrS5oGpCcWrrqmq7HiTKOGVmIpwym0vAdsd062mG0VKtujB9mbGlwg6q3PQyxHMoMrIxljuOa6mmp8cP0FrcBrZnNcIDdJGqtq511VboPLMfTzt1E3GuPC7tgVzw/cl4DXNAOgBmfQLKh4lW1ynktfraNNbGqUt0pdsAb+GrnXtHZCNtCc3jKZnqYRWdra8/kH13iGl0e2N2VkXWvDl3XqGmxoJAmZAEeHVN0uNkd0exNcqbsSjPh+YbU4PrUZNSJG422TCcY9xmzwmyUd1M1IJ4cpFlwCWaGAEO6cWsJiC0V9fvTi0jrfs0Mzd2ISjsa7lnU15Cw4lR6hV6jOUUVuuqB5tQpNsJHg8aaHKELZyEUsi2sASYXqtKsVI19K2lyWWDzlIPJZmo5uwzP1vxszuJVzmcIG69Fpa6VBKNmDw+tsudkt1aa/EpfcmIYyDzMJidUMYssyK12S7114ZWA46f4VYw0a88lpWat+WPwLK7wxsTJ6ckx0p4/wAtKK9X3FlOEnmxuT9F2GPBDyK5kGDSInkTmafwUpZOtTUE8y839A065urqNYinwvqdEoOkKjAplb3a+SulwBlJ54FmKCYOnQJmnjgzdanLDGVjRysHkl7JbpGhp61XWhTilDvmp1/xA+sKmps2aWa+WPx4LaHT9TxKp/8AbP4LP7HxPcXkPI+leZn6hmu3+3vH5bfUhK6hZpn9P3RfOGv69X+w6dhzKsFwBXmetOvhBGO7WixjMjdBEQkJzlKe5lcPImPD9J1TMRzlOrWzjDBY0FeixzMnKIWfGclLcCWciN3D1NaS8Rnjsghn8Ixd1s4tcM1J+4+E9Qt7V6aViUq5YkvwZ2ISWJfbH6DKxx+8FQMpMY5pOjXEZnDznTRPaTSZXU6iCU+H6b2bfNSy/P8A8ZHiThy5rFtSW0RqS3Od940WppdTPT5W1PJnW6ai6O2Dk5L8DT4fQaKIYdW5I3kkAayeZ8V5mfh89RqJXah/TB0v8lbV5epgcTt7MVSGB7dNiCJPOCUe66WM1PjzNJUarTU+1UqM3Huk1n+5oODL5tNjmtzASSA6f+5LG1tuo3qUZYfbgWnrJ+JVq6cNr7YYqxyvWpVqlam9oYQMzd5PMjoV7OCjPw2NL+P1M6/wvXR09k6ZY4ztS7+v3wLMKdVuHF1uw1MpGZ2YAA78+a8/bp+lFO57U+2Txuh8K1FtinnGGufMYXt1XY8NuWiOTQfrmHNH0VsJ1yUJNrzPq8/BdD4hpVCfvNeb75JW1nXpVg5jC+YLQ0w5nOCdiFrVeKUdDpURal9OGeW02i0Wn1D03UbjH65X0x3HGO3rXdmatB/aD3myAB8+af0Xh71VbldLCfHH9cGnZr5aDMaPfWM5WO33CbK8tg2WU8ro5gaEH6pLV6CGjy084K9a3WRw21xlC6tjDqxytMaEEDbRZk7epwy2lnLoZnyxe7AzO25+6KmBwNWcHtyzn1V9rJ4BK3D5pal31V6lixbglUU5A8QfBeljjGEbEFgjc3XZyQNxokVp4W34lLCMPxjUOlborLM9q9xdIBnmVvJVwSr2ZXqjwznZY3ZvSfo2EPLRu/XwRFU18Fax8wbsz8drz8l/YspVGCS6dBJB3jy5JXUTfCTS5xwM6evu5KT4zz/IiaNM/uQD0aeX+0J+7Lp6hyXo88BcJx6mnUX6rHIZhFzNUOAiNx5/6KR8QlbpbIZeUnlfNdmaHh9VWspsWMNpJ/J+X5m6tn6AytFNSWUeelFwltlw1w/sRq0uvPVGjIUnD18yuq1stzGA35CVMd2HgHNQzHdwkTfdgzl90c+vl1UKvHfuXlqFLO3svMVXT3uEnRpMNHM85+iT8XcYadx821/P9jR/htTt1ym+yUmvyX7k6phi8q/hPoC7mf8AaSx7qkAhoObXUAAuMDnyTul06s010pLKx+ff9kY3imqlXqtPVB4bll/Ttz9cv7ohS4wZ0PoViPTr0RsbghnGFPx9ChPSxf8AtRO4up8XUuqr7HD/AIo7eFU+LKPxKPYqv+J25lv6mo/EFPsVX/FHbmZ/EaK0UEBuG2uF00seGuExIkHTUeirZKcUtv8AYfWulPTOizleT8zX4xXrOADyCeRYIA06Eld1uXGx915Cvh9cd04ptZXf0MfjFGuXtFMuZAIkGJzeC2dDr6K4NTju+3p9SnjlMr4xhGWPX5g77S5cG5o7o3n6rBs1NCtm0u77D/gLjo9N0nHPL5yafAKkMyviY3WHqY7p5h2KalKU3KKwmwC9w/MXakA+i3YaycYLgbeolCnDfl3GHBVubdtRtNwbmcCQ4TrG4WV4vqlqVHdl4PPV0wWcHuOU3VKzHOcCWmQI08iltJPpVtQysmxpZSrqkovuhtTvnho0IIHIiPNei0l9cao5i84FqNPFwW7n9RZxAx9ZzXE6hsbnn5La0fiOoqWK4pr5mZdodPYm5Np/J+XzF9ng9R3vVDHQaQs7xDV3X53cDNMI1rC9OBvYYeyntus2FeHlnKfuYD3VY1TG/HINLkmbqoQYLZju+Csr+/AVxQjZTrye2q5p20AjyVfaH5ojZ6DbB8KpUxmqP7V06NEQOnmtWGpm4YyRK27G1PgLxLG7IHsarqZJ0LYBA8CUNyFXW33/ADMjj1O1bVik0ZcoJykxJ+a1tPq9Qq8KXBi6rR6fqcwFr6lFslrRmAmd49VMrbp/FJlI1Uw+GKFIfmGYbkyfE+K0NJHKenn59vqIal4cb4eXcsfXgSN+ivW+rGWnt+JdmVnHpyWoq+F90MOHnakled8RsnKUYS/2r9z0vhlcIwlOP+55/I1+AXbXNcw6lrvmA7Ufn0Wj4bJunHoef8bgo6jdjhobt001I+y0DGfoeRrtordgeG2WPYI1iFVN+QSUY494V4hWa5zWNIMEkxGm0D6rH8Yk0owfnz+x6P8AhuEW7LI9liK/V/ogfETDfksSZ6qInw4cyNzJJ8djHPSF6jw7TbdH/wDWX+P/AIfO/HtYpeJZ8oYX4cv/APTYkr4R2Tiw6wAQ74mnY/8AdF5TUVSpscJHu9LqIampWw8/yKvYggZGMFlOxCnJwJil0yicoGZ+5HIdJWlotC71ulwv1M7Wa6ND2pZYtOLu+Bq0v8Jp9WZv+LW+iN3ftC8+enRnLlxa4OboWmQfEaoiWVgrI2DK4e1rviaHCfESkbEH09igmvUXXoJPOB4/5XV2OPYm+fUaBu0d4EDzSk4rLZeNjSwi2gSNf/vqh+YaDygmm/Md/MFNyn7mClsMxaLmvjwWZKtmb02ih9Q5kxClYH67WlgvqXjoEJiOUDhJrsTtaubcyfmtTT3bYJMVsT3Nh9MlDus3tkLhEsyEcU1H+MKGSkA3dYtEz/tdFbngZ01PVsUPUCGJ5nBsmTqPL/grSqcVufyNC/w11VOzPbA5s6zXw14167H6KYGbKLSyQq8P0Sfdbr1Gvqpw0+GC3Z8gK9wek10BoiEeF04rEZMXnXCby0gF2B0nHK0uaXGN5EnzCZjrLV35FLtPTCDm8pJN8fIq/Sr2jSo2ACTIMwNAdJmYT8/G4zcJbcSS9e55+v2bc6t7xLZj3fOfwrv+PkX23CYdq5x5a/6Cpb4rfbb1IJR/P9f5G5X4ZRVXsk3L8v0/mD4haCkP2jtvI/O6Vds7puU3lsZVcaa9sFhIH4cxd7Ls6d1zcrx4t1BHqfVa3h8cT2eufyPPeMzTr6v/ABaX49/2N6/E3FsU2gnnOgH+VsRpWfeZ5mzVtx/y0BCtVLwx1SCQSGNEuIG5zGAN/HyRHsXZAoq2XDb+2AbEbtjIa4OqVDJDXPcWgbSQA1p9Cq7v6x/cnDfCX4vP9fp8z2xJk5g1pEjKwQ0QToI+68l4jerdQ2uy4X9fU+ieDaV6fSRjL4n7z+/bt8sHmKEkR8RDR5uMflIPlmrnCbLG2jJMEkATG2y214tdt2pL8H/M8hP+HtLKbnOUm28vlct9+yPcZw1tSiKrfeY2R/czcg+I1Pr1WXq1Kxucnyb2jjCiKrgsIyzSs40SVxdCnTc86wNup5BG09TtsUF5gr7FVBzfkZBzHOJe4ySZPmvYVQUIqK7I8ddY5ycpd2UOYig8n//Z') no-repeat center center/cover;
      height: 500px;
      display: flex;
      justify-content: center;
      align-items: center;
      flex-direction: column;
      color: white;
      text-align: center;
      padding: 20px;
    }

    .hero h2 { font-size: 2.5em; margin-bottom: 10px; }
    .hero p { max-width: 600px; line-height: 1.6; font-size: 1.1em; }

    .hero a {
      background: #fff;
      color: #ff6f00;
      padding: 10px 20px;
      border-radius: 5px;
      font-weight: bold;
      margin-top: 20px;
      transition: 0.3s;
    }

    .hero a:hover { background: #ff6f00; color: #fff; }

    /* About & Featured Section */
    section {
      width: 90%;
      max-width: 1100px;
      margin: 50px auto;
      background: white;
      border-radius: 10px;
      padding: 40px;
      box-shadow: 0 3px 8px rgba(0,0,0,0.1);
    }

    section h2 {
      color: #ff6f00;
      text-align: center;
      margin-bottom: 20px;
    }

    section p {
      text-align: center;
      color: #555;
      line-height: 1.8;
      font-size: 1.05em;
    }

    .sitters {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
      gap: 25px;
      margin-top: 30px;
    }

    .sitter-card {
      background: #fff;
      border-radius: 10px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
      overflow: hidden;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      text-align: center;
      padding-bottom: 20px;
    }

    .sitter-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 6px 15px rgba(0,0,0,0.15);
    }

    .sitter-card img {
      width: 100%;
      height: 200px;
      object-fit: cover;
    }

    .sitter-card h3 {
      margin: 15px 0 5px;
      color: #ff6f00;
    }

    .sitter-card p { margin: 5px 0; color: #666; }

    .sitter-card a {
      display: inline-block;
      margin-top: 10px;
      background: #ff6f00;
      color: white;
      padding: 8px 16px;
      border-radius: 5px;
      font-weight: 500;
    }

    .sitter-card a:hover { background: #e65c00; }

    footer {
      background: #333;
      color: #fff;
      text-align: center;
      padding: 20px;
      margin-top: 60px;
      font-size: 0.95em;
    }
  </style>
</head>
<body>

<header>
  <h1>Daycare</h1>
  <nav>
    <a href="index.php">Home</a>
    <a href="about.html">About</a>
    <a href="explore_sitters.php">Explore Sitters</a>
    <a href="contact.html">Contact</a>
    <a href="feedback.html">Feedback</a>
    <a href="login.php">Login</a>
    <a href="register.php">Register</a>
  </nav>
</header>

<!-- Hero Section -->
<div class="hero">
  <h2>Find Trusted Babysitters Near You</h2>
  <p>ChaguaSitter helps parents connect with reliable, verified babysitters quickly and easily. 
     Your child’s safety and happiness are our top priority.</p>
  <a href="explore_sitters.php">Explore Sitters</a>
</div>

<!-- Featured Sitters Section -->
<section>
  <h2>Featured Sitters</h2>
  <div class="sitters">
    <?php
    $query = "
      SELECT s.*, u.fullname 
      FROM sitters s
      JOIN users u ON s.user_id = u.id
      LIMIT 3
    ";
    $result = $conn->query($query);

    if ($result && $result->num_rows > 0) {
      while ($row = $result->fetch_assoc()) {
        echo "
        <div class='sitter-card'>
          <img src='images/default_sitter.png' alt='Sitter'>
          <h3>".htmlspecialchars($row['fullname'])."</h3>
          <p>Experience: ".htmlspecialchars($row['experience'])." yrs</p>
          <p>Rate: Ksh ".htmlspecialchars($row['hourly_rate'])."/hr</p>
          <a href='login.php'>Book Now</a>
        </div>
        ";
      }
    } else {
      echo "<p style='text-align:center; color:#666;'>No sitters available yet.</p>";
    }
    ?>
  </div>
</section>

<footer>
  <p>&copy; <?php echo date('Y'); ?> ChaguaSitter. All rights reserved.</p>
  </footer>
  <script src="script.js"></script>
</body>
</html>
<?php include 'footer.php'; ?>



