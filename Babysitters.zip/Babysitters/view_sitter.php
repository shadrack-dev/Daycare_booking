<?php
session_start();
include 'db_connect.php';

// Check if sitter ID is provided in the URL
if (!isset($_GET['id'])) {
  echo "Invalid sitter ID.";
  exit;
}

$sitter_id = intval($_GET['id']);

// Fetch sitter details
$sql = "SELECT u.fullname, u.email, s.phone, s.experience, s.bio, s.hourly_rate, s.availability
        FROM sitters s
        JOIN users u ON s.user_id = u.id
        WHERE s.sitter_id = $sitter_id";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
  echo "Sitter not found.";
  exit;
}

$sitter = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($sitter['fullname']); ?> | Babysitter Profile</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body {
      font-family: Arial, sans-serif;
      background: url("https://images.unsplash.com/photo-1600880292089-90e3a522b10f?auto=format&fit=crop&w=1600&q=60") center/cover no-repeat;
      margin: 0;
      color: #333;
    }
    header {
      background: rgba(0, 0, 0, 0.6);
      color: #fff;
      text-align: center;
      padding: 1.2rem 0;
    }
    .container {
      max-width: 800px;
      margin: 2rem auto;
      background: rgba(255, 255, 255, 0.9);
      padding: 2rem;
      border-radius: 12px;
      box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
    }
    .sitter-profile {
      display: flex;
      align-items: center;
      gap: 2rem;
    }
    .sitter-profile img {
      width: 160px;
      height: 160px;
      border-radius: 10px;
      object-fit: cover;
    }
    h2 {
      color: #0077cc;
      margin-bottom: 0.5rem;
    }
    .btn {
      display: inline-block;
      background: #0077cc;
      color: #fff;
      padding: 10px 20px;
      border-radius: 6px;
      text-decoration: none;
      margin-top: 1rem;
    }
    .btn:hover {
      background: #005fa3;
    }
    footer {
      text-align: center;
      background: #333;
      color: #fff;
      padding: 1rem;
      margin-top: 2rem;
    }
  </style>
</head>
<body>

<header>
  <h1>Babysitter Profile</h1>
</header>

<div class="container">
  <div class="sitter-profile">
    <img src="https://images.unsplash.com/photo-1607746882042-944635dfe10e?auto=format&fit=crop&w=400&q=60" alt="Sitter Photo">
    <div>
      <h2><?= htmlspecialchars($sitter['fullname']); ?></h2>
      <p><b>Email:</b> <?= htmlspecialchars($sitter['email']); ?></p>
      <p><b>Phone:</b> <?= htmlspecialchars($sitter['phone']); ?></p>
      <p><b>Experience:</b> <?= htmlspecialchars($sitter['experience']); ?> years</p>
      <p><b>Rate:</b> KSh <?= htmlspecialchars($sitter['hourly_rate']); ?> /hr</p>
      <p><b>Status:</b> <?= htmlspecialchars($sitter['availability']); ?></p>
    </div>
  </div>

  <hr style="margin: 2rem 0;">

  <h3>About <?= htmlspecialchars($sitter['fullname']); ?></h3>
  <p><?= nl2br(htmlspecialchars($sitter['bio'])); ?></p>

  <a href="login.php" class="btn">Book This Sitter</a>
  <a href="index.php" class="btn" style="background:#555;">Back to List</a>
</div>

<footer>
  <p>&copy; 2025 ChaguaSitter | Your trusted babysitting platform </p>
</footer>
<script src="script.js"></script>
</body>
</html>