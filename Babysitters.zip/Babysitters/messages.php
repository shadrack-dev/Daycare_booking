<?php
session_start();
include 'db_connect.php';

// Ensure the user is logged in as a parent
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'parent') {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$message_error = "";
$message_success = "";

// Handle sending a new message
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_message'])) {
    $sitter_name = trim($_POST['sitter_name']);
    $message_content = trim($_POST['message']);

    if ($sitter_name && $message_content) {
        $stmt = $conn->prepare("INSERT INTO messages (parent_id, sitter_name, message, sent_at) VALUES (?, ?, ?, NOW())");
        $stmt->bind_param("iss", $user_id, $sitter_name, $message_content);
        if ($stmt->execute()) {
            $message_success = "Message sent successfully!";
        } else {
            $message_error = "Failed to send message.";
        }
    } else {
        $message_error = "Please fill in all fields.";
    }
}

// Fetch all messages sent by this parent
$stmt = $conn->prepare("SELECT * FROM messages WHERE parent_id = ? ORDER BY sent_at DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$messages_result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Messages | ChaguaSitter</title>
<style>
body { font-family: "Poppins", sans-serif; background: #f2f6f7; margin: 0; color: #333; display: flex; flex-direction: column; min-height: 100vh; }
header { background-color: #2b6777; color: white; padding: 15px 30px; display: flex; justify-content: space-between; align-items: center; }
.nav-right a { color: white; text-decoration: none; margin-left: 20px; font-weight: bold; }
.nav-right a:hover { text-decoration: underline; }
.sidebar { background-color: #52ab98; width: 230px; height: 100%; position: fixed; top: 0; left: 0; padding-top: 80px; display: flex; flex-direction: column; transition: 0.3s; }
.sidebar a { color: white; padding: 15px 20px; text-decoration: none; display: block; }
.sidebar a:hover, .sidebar a.active { background-color: #3f8b79; }
.menu-toggle { display: none; font-size: 24px; background: none; border: none; color: white; cursor: pointer; }
.main-content { margin-left: 230px; padding: 40px; flex: 1; }
@media (max-width: 768px) { .sidebar { left: -230px; } .sidebar.active { left: 0; } .menu-toggle { display: block; } .main-content { margin-left: 0; padding: 20px; } }
h3 { color: #2b6777; border-bottom: 2px solid #52ab98; padding-bottom: 5px; }
table { width: 100%; border-collapse: collapse; margin-top: 20px; background: white; border-radius: 10px; overflow: hidden; box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
th, td { text-align: left; padding: 12px 15px; border-bottom: 1px solid #ddd; }
th { background-color: #52ab98; color: white; }
tr:hover { background-color: #f1f1f1; }
form { background: white; padding: 20px; border-radius: 10px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); margin-top: 20px; }
input[type="text"], textarea { width: 100%; padding: 10px; margin: 8px 0; border-radius: 6px; border: 1px solid #ccc; }
button { padding: 10px 20px; background: #52ab98; color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: bold; }
button:hover { background: #3f8b79; }
.error-msg { color: red; margin-top: 15px; font-weight: bold; }
.success-msg { color: green; margin-top: 15px; font-weight: bold; }
footer { background-color: #2b6777; color: white; text-align: center; padding: 15px; margin-top: auto; }
</style>
</head>
<body>

<header>
  <div style="display: flex; align-items: center; gap: 15px;">
    <button class="menu-toggle" onclick="toggleMenu()">☰</button>
    <h2>ChaguaSitter | Messages</h2>
  </div>
  <div class="nav-right">
    <a href="profile.php">Profile</a>
    <a href="logout.php">Logout</a>
  </div>
</header>

<div class="sidebar" id="sidebar">
  <a href="parent_dashboard.php"> Dashboard</a>
  <a href="explore_sitters.php"> Explore Sitters</a>
  <a href="bookings.php">My Bookings</a>
  <a href="messages.php" class="active"> Messages</a>
  <a href="payments.php"> Payments</a>
</div>

<div class="main-content">
  <h3>Send a Message</h3>

  <?php if ($message_error): ?>
      <p class="error-msg"><?php echo htmlspecialchars($message_error); ?></p>
  <?php elseif ($message_success): ?>
      <p class="success-msg"><?php echo htmlspecialchars($message_success); ?></p>
  <?php endif; ?>

  <form method="POST" action="">
    <label for="sitter_name">Sitter Name:</label>
    <input type="text" name="sitter_name" id="sitter_name" placeholder="Enter sitter's name" required>

    <label for="message">Message:</label>
    <textarea name="message" id="message" rows="4" placeholder="Write your message..." required></textarea>

    <button type="submit" name="send_message">Send Message</button>
  </form>

  <h3>Message History</h3>
  <?php if ($messages_result && $messages_result->num_rows > 0): ?>
    <table>
      <tr>
        <th>#</th>
        <th>Sitter Name</th>
        <th>Message</th>
        <th>Date Sent</th>
      </tr>
      <?php while ($msg = $messages_result->fetch_assoc()): ?>
      <tr>
        <td><?php echo $msg['id']; ?></td>
        <td><?php echo htmlspecialchars($msg['sitter_name']); ?></td>
        <td><?php echo htmlspecialchars($msg['message']); ?></td>
        <td><?php echo date('d M Y H:i', strtotime($msg['sent_at'])); ?></td>
      </tr>
      <?php endwhile; ?>
    </table>
  <?php else: ?>
    <p>No messages sent yet.</p>
  <?php endif; ?>
</div>

<footer>
  <p>© <?php echo date("Y"); ?> ChaguaSitter. All Rights Reserved.</p>
</footer>

<script>
function toggleMenu() {
  document.getElementById('sidebar').classList.toggle('active');
}
</script>
</body>
</html>
