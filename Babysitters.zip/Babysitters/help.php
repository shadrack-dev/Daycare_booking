<?php
session_start();
include('db_connect.php');

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Help & FAQ | ChaguaSitter</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body {
      font-family: "Poppins", sans-serif;
      background-color: #f9f9f9;
      margin: 0;
      color: #333;
    }

    .help-container {
      width: 90%;
      max-width: 1000px;
      margin: 60px auto;
      background: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }

    h1 {
      text-align: center;
      color: #ff6f00;
      margin-bottom: 30px;
    }

    .faq {
      margin-bottom: 20px;
    }

    .faq h3 {
      color: #222;
      cursor: pointer;
      background: #ffedd2;
      padding: 10px;
      border-radius: 5px;
      transition: 0.3s;
    }

    .faq h3:hover {
      background: #ffcc80;
    }

    .faq p {
      display: none;
      padding: 10px;
      line-height: 1.6;
      background: #fff7e6;
      border-left: 4px solid #ff6f00;
      border-radius: 5px;
    }

    .faq.active p {
      display: block;
    }

    @media (max-width: 768px) {
      .help-container {
        width: 95%;
        padding: 20px;
      }
    }
  </style>
</head>
<body>

<div class="help-container">
  <h1>Help & Frequently Asked Questions</h1>

  <div class="faq">
    <h3>What is ChaguaSitter?</h3>
    <p>ChaguaSitter is an online platform that connects parents with trusted, verified babysitters across Africa. Our goal is to make childcare safer and easier to access.</p>
  </div>

  <div class="faq">
    <h3>How do I make a booking?</h3>
    <p>Simply browse available sitters, view their profiles, and click "Book Now." You’ll be prompted to log in or register before confirming your booking.</p>
  </div>

  <div class="faq">
    <h3>How can I become a sitter?</h3>
    <p>Create an account as a sitter and fill in your professional details such as years of experience, availability, and hourly rate. Once verified, your profile will appear publicly.</p>
  </div>

  <div class="faq">
    <h3>Is my data secure?</h3>
    <p>Yes, we use secure password encryption and SSL to ensure your information remains private and protected.</p>
  </div>

  <div class="faq">
    <h3>Need more help?</h3>
    <p>Contact us via <a href="contact.php">our Contact page</a> or email us directly at <b>support@chaguasitter.com</b>.</p>
  </div>
</div>

<script>
  document.querySelectorAll(".faq h3").forEach((faq) => {
    faq.addEventListener("click", () => {
      faq.parentElement.classList.toggle("active");
    });
  });
</script>
<script src="script.js"></script>
</body>
</html>
