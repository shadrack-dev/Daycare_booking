<footer>
  <style>
    footer {
      background: #2e2e2e;
      color: #fff;
      padding: 50px 0 20px 0;
      font-family: 'Poppins', sans-serif;
    }
.footer-container {
      width: 90%;
      max-width: 700px;
      margin:  auto;
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 50px;
      height: 50%;
    }
    

    .footer-logo h2 {
      color: #ff6f00;
      font-size: 24px;
      margin-bottom: 10px;
    }

    .footer-logo p {
      color: #ccc;
      font-size: 14px;
      line-height: 1.6;
    }

    .footer-links h3,
    .footer-contact h3,
    .footer-newsletter h3 {
      color: #fff;
      font-size: 18px;
      margin-bottom: 15px;
      position: relative;
    }

    .footer-links a {
      color: #ccc;
      display: block;
      text-decoration: none;
      margin-bottom: 8px;
      font-size: 14px;
      transition: 0.3s;
    }

    .footer-links a:hover {
      color: #ff6f00;
    }

    .footer-contact p {
      color: #ccc;
      font-size: 14px;
      line-height: 1.8;
    }

    .footer-contact i {
      color: #ff6f00;
      margin-right: 8px;
    }

    .footer-newsletter input[type="email"] {
      width: 80%;
      padding: 10px;
      border: none;
      border-radius: 4px;
      margin-bottom: 10px;
      font-size: 14px;
    }

    .footer-newsletter button {
      background: #ff6f00;
      color: white;
      border: none;
      padding: 10px 20px;
      border-radius: 4px;
      cursor: pointer;
      font-size: 14px;
      transition: background 0.3s;
    }

    .footer-newsletter button:hover {
      background: #e65c00;
    }

    .social-icons {
      margin-top: 15px;
    }

    .social-icons a {
      color: #ff6f00;
      text-decoration: none;
      margin-right: 10px;
      font-size: 20px;
      transition: 0.3s;
    }

    .social-icons a:hover {
      color: white;
    }
    

    .footer-bottom {
      text-align: center;
      border-top: 1px solid #444;
      margin-top: 40px;
      padding-top: 15px;
      font-size: 13px;
      color: #aaa;
    }

    @media (max-width: 768px) {
      .footer-newsletter input[type="email"] {
        width: 100%;
      }
    }
  </style>

  <div class="footer-container">

    <!-- Logo & Description -->
    <div class="footer-logo">
      <h2>ChaguaSitter</h2>
      <p>
        Kenyan trusted platform for finding reliable, loving babysitters and daycare providers.
        We connect parents with verified sitters to ensure every child is cared for with love and safety 💛.
      </p>
      <div class="social-icons">
        <a href="#"><i class="fab fa-facebook-f"></i></a>
        <a href="#"><i class="fab fa-instagram"></i></a>
        <a href="#"><i class="fab fa-twitter"></i></a>
        <a href="#"><i class="fab fa-linkedin"></i></a>
      </div>
    </div>

    <!-- Quick Links -->
    <div class="footer-links">
      <h3>Quick Links</h3>
      <a href="index.php">Home</a>
      <a href="about.php">About Us</a>
      <a href="book_now.php">Book Now</a>
      <a href="feedback.php">Feedback</a>
      <a href="contact.php">Contact</a>
      <a href="help.php">Help</a>
    </div>

    <!-- Contact Info -->
    <div class="footer-contact">
      <h3>Contact Us</h3>
      <p><i class="fas fa-phone-alt"></i> +254 701 123 456</p>
      <p><i class="fas fa-envelope"></i> support@chaguasitter.com</p>
      <p><i class="fas fa-map-marker-alt"></i> Nairobi, Kenya</p>
    </div>

    <!-- Newsletter -->
    <div class="footer-newsletter">
      <h3>Join Our Newsletter</h3>
      <form>
        <input type="email" placeholder="Enter your email" required>
        <button type="submit">Subscribe</button>
      </form>
      <p style="color:#aaa; font-size:13px;">Stay updated with parenting tips and sitter opportunities!</p>
    </div>

  </div>

  <div class="footer-bottom">
    <p>&copy; <?php echo date('Y'); ?> ChaguaSitter | Caring for Africa’s Future 💛</p>
  </div>

  <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</footer>
