<?php
session_start();
include 'db_connect.php';

// Ensure parent is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'parent') {
    header('Location: index.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Get parent ID
$stmt = $conn->prepare("SELECT parent_id FROM parents WHERE user_id = ?");
$stmt->bind_param('i', $user_id);
$stmt->execute();
$parent = $stmt->get_result()->fetch_assoc();
if (!$parent) die("Parent not found.");

$parent_id = $parent['parent_id'];

// Booking limits
$parent_daily_limit = 3;
$system_daily_limit = 20;
$today = date('Y-m-d');

// Count today's bookings
$stmt = $conn->prepare("SELECT COUNT(*) AS c FROM bookings WHERE parent_id=? AND DATE(booking_date)=?");
$stmt->bind_param('is', $parent_id, $today);
$stmt->execute();
$pCount = $stmt->get_result()->fetch_assoc()['c'];

$stmt = $conn->prepare("SELECT COUNT(*) AS t FROM bookings WHERE DATE(booking_date)=?");
$stmt->bind_param('s', $today);
$stmt->execute();
$sCount = $stmt->get_result()->fetch_assoc()['t'];

// Slots left
$parent_slots_left = max(0, $parent_daily_limit - $pCount);
$system_slots_left = max(0, $system_daily_limit - $sCount);

// Progress percentages
$parent_progress = round(($pCount / $parent_daily_limit) * 100);
$system_progress = round(($sCount / $system_daily_limit) * 100);

// Dynamic colors
function getProgressColor($percentage){
    if($percentage < 30) return '#4caf50';
    elseif($percentage < 70) return '#ff9800';
    else return '#f44336';
}

// Fetch all bookings with child conditions
$query = "
  SELECT b.booking_id, b.booking_date, b.status, b.duration, b.child_conditions, s.hourly_rate, u.fullname AS sitter_name
  FROM bookings b
  LEFT JOIN sitters s ON b.sitter_id = s.sitter_id
  LEFT JOIN users u ON s.user_id = u.id
  WHERE b.parent_id = ?
  ORDER BY b.booking_date DESC
";
$stmt = $conn->prepare($query);
$stmt->bind_param('i', $parent_id);
$stmt->execute();
$result = $stmt->get_result();

function calculatePayment($rate, $duration) {
    return $rate * $duration;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Bookings | ChaguaSitter</title>
<style>
body{font-family:'Poppins',sans-serif;background:#f8f8f8;margin:0;padding:0;}
header{background:#f68b1e;color:#fff;padding:15px 40px;display:flex;justify-content:space-between;align-items:center;}
header a{color:#fff;text-decoration:none;}
.container{max-width:1100px;margin:40px auto;background:#fff;padding:25px;border-radius:12px;box-shadow:0 5px 15px rgba(0,0,0,0.1);}
h2{text-align:center;color:#f68b1e;margin-bottom:25px;}
.notice{padding:12px 15px;border-radius:6px;margin-bottom:20px;font-size:15px;}
.success{background:#e0f7fa;border-left:5px solid #4caf50;color:#007c91;}
.error{background:#fff3e0;border-left:5px solid #f44336;color:#444;}
.slots{background:#e0f7fa;border-left:5px solid #00acc1;padding:10px 15px;border-radius:6px;margin-bottom:10px;font-size:15px;text-align:center;font-weight:600;color:#007c91;}
.progress-container{background:#eee;border-radius:10px;overflow:hidden;height:20px;margin-bottom:20px;}
.progress-bar{height:100%;text-align:center;color:#fff;line-height:20px;font-size:12px;}
table{width:100%;border-collapse:collapse;margin-top:20px;font-size:14px;}
th,td{padding:10px 12px;border:1px solid #ddd;}
th{background-color:#f68b1e;color:#fff;}
tr:nth-child(even){background-color:#f9f9f9;}
.status-pending{color:#f68b1e;font-weight:600;}
.status-completed{color:green;font-weight:600;}
.status-cancelled{color:red;font-weight:600;}
.btn{background:#f68b1e;color:#fff;padding:8px 15px;border-radius:6px;text-decoration:none;font-size:14px;}
.btn:hover{background:#e67e1e;}
footer{text-align:center;color:#fff;background:#f68b1e;padding:12px;margin-top:40px;font-size:13px;}
</style>
</head>
<body>

<header>
<h2>🧡 ChaguaSitter | My Bookings</h2>
<nav><a href="add_booking.php">+ Add Booking</a></nav>
</header>

<div class="container">
<h2>Your Bookings</h2>

<!-- Success/Error messages -->
<?php if(isset($_SESSION['success'])): ?>
    <div class="notice success"><?= $_SESSION['success']; unset($_SESSION['success']); ?></div>
<?php endif; ?>
<?php if(isset($_SESSION['error'])): ?>
    <div class="notice error"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
<?php endif; ?>

<!-- Parent progress -->
<div class="slots">Your Slots Left Today: <?= $parent_slots_left ?></div>
<div class="progress-container">
    <div class="progress-bar" style="width:<?= $parent_progress ?>%; background: <?= getProgressColor($parent_progress) ?>;">
        <?= $parent_progress ?>%
    </div>
</div>

<!-- System progress -->
<div class="slots">System Slots Left Today: <?= $system_slots_left ?></div>
<div class="progress-container">
    <div class="progress-bar" style="width:<?= $system_progress ?>%; background: <?= getProgressColor($system_progress) ?>%;">
        <?= $system_progress ?>%
    </div>
</div>

<table>
<tr>
  <th>Booking ID</th>
  <th>Sitter</th>
  <th>Booking Date</th>
  <th>Duration (hrs)</th>
  <th>Child Conditions</th>
  <th>Status</th>
  <th>Total Payment (Ksh)</th>
</tr>

<?php
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $payment = calculatePayment($row['hourly_rate'], $row['duration']);
        $statusClass = match($row['status']) {
            'completed' => 'status-completed',
            'cancelled' => 'status-cancelled',
            default => 'status-pending'
        };
        echo "
        <tr>
            <td>{$row['booking_id']}</td>
            <td>{$row['sitter_name']}</td>
            <td>{$row['booking_date']}</td>
            <td>{$row['duration']}</td>
            <td>".htmlspecialchars($row['child_conditions'])."</td>
            <td class='{$statusClass}'>{$row['status']}</td>
            <td><strong>Ksh ".number_format($payment,2)."</strong></td>
        </tr>";
    }
} else {
    echo "<tr><td colspan='7' style='text-align:center;color:#888;'>No bookings found</td></tr>";
}
?>
</table>
</div>

<footer>© <?= date("Y") ?> ChaguaSitter. All rights reserved.</footer>
<script src="script.js"></script>
</body>
</html>
