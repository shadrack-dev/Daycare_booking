
// 🕒 Display real-time clock
function updateClock() {
  const clock = document.getElementById("clock");
  if (clock) {
    const now = new Date();
    const timeString = now.toLocaleTimeString();
    clock.textContent = timeString;
  }
}
setInterval(updateClock, 1000);
updateClock();

// 👋 Dynamic greeting based on time
function updateGreeting() {
  const greeting = document.getElementById("greeting");
  if (greeting) {
    const hours = new Date().getHours();
    let message = "Welcome back!";

    if (hours < 12) message = "🌅 Good morning!";
    else if (hours < 18) message = "☀️ Good afternoon!";
    else message = "🌙 Good evening!";

    greeting.textContent = message;
  }
}
updateGreeting();

// 🔔 Notification system
function showNotification(message, type = "info") {
  const notif = document.createElement("div");
  notif.className = `notification ${type}`;
  notif.innerHTML = `<strong>${type.toUpperCase()}:</strong> ${message}`;
  document.body.appendChild(notif);

  setTimeout(() => {
    notif.classList.add("show");
  }, 10);

  setTimeout(() => {
    notif.classList.remove("show");
    setTimeout(() => notif.remove(), 300);
  }, 4000);
}

// 🧾 Filter bookings by status
function filterBookings() {
  const filter = document.getElementById("statusFilter");
  const selectedStatus = filter.value.toLowerCase();
  const rows = document.querySelectorAll("#bookingTable tbody tr");

  rows.forEach(row => {
    const status = row.querySelector(".status").textContent.toLowerCase();
    if (selectedStatus === "all" || status === selectedStatus) {
      row.style.display = "";
    } else {
      row.style.display = "none";
    }
  });
}

// 🚪 Confirm logout
function confirmLogout() {
  return confirm("Are you sure you want to log out?");
}

// 💬 Welcome message after login
document.addEventListener("DOMContentLoaded", () => {
  const userWelcome = document.getElementById("userWelcome");
  if (userWelcome) {
    showNotification(`Welcome ${userWelcome.textContent || 'User'} 👋`, "success");
  }
});

// 🪄 Animation for smooth fade-ins
document.addEventListener("DOMContentLoaded", () => {
  const sections = document.querySelectorAll(".section");
  sections.forEach((section, index) => {
    section.style.opacity = "0";
    section.style.transform = "translateY(30px)";
    setTimeout(() => {
      section.style.transition = "all 0.6s ease";
      section.style.opacity = "1";
      section.style.transform = "translateY(0)";
    }, index * 200);
  });
});
