<?php
session_start();
include 'db_connect.php';

// Ensure parent is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'parent') {
    header("Location: login.php");
    exit();
}

$parent_id = $_SESSION['user_id'];
$message = "";

// Handle booking
if (isset($_POST['submit'])) {
    $sitter_id = $_POST['sitter_id'];
    $booking_date = $_POST['booking_date'];

    // Check sitter availability
    $check = $conn->prepare("SELECT availability FROM sitters WHERE sitter_id = ?");
    $check->bind_param("i", $sitter_id);
    $check->execute();
    $result = $check->get_result();

    if ($result->num_rows > 0) {
        $sitter = $result->fetch_assoc();

        if ($sitter['availability'] == 1) {
            // Book sitter
            $status = 'approved';
            $insert = $conn->prepare("INSERT INTO bookings (parent_id, sitter_id, booking_date, status) VALUES (?, ?, ?, ?)");
            $insert->bind_param("iiss", $parent_id, $sitter_id, $booking_date, $status);
            $insert->execute();

            // Update sitter availability (busy)
            $conn->query("UPDATE sitters SET availability = 0 WHERE sitter_id = $sitter_id");

            // Send notification to parent
            $notify = $conn->prepare("INSERT INTO notifications (parent_id, message, is_ready) VALUES (?, ?, 0)");
            $msg = "Your booking has been approved automatically. Sitter is available.";
            $notify->bind_param("is", $parent_id, $msg);
            $notify->execute();

            $message = "✅ Booking approved successfully!";
        } else {
            // No sitter available
            $status = 'rejected';
            $insert = $conn->prepare("INSERT INTO bookings (parent_id, sitter_id, booking_date, status) VALUES (?, ?, ?, ?)");
            $insert->bind_param("iiss", $parent_id, $sitter_id, $booking_date, $status);
            $insert->execute();

            // Send rejection notification
            $notify = $conn->prepare("INSERT INTO notifications (parent_id, message, is_ready) VALUES (?, ?, 0)");
            $msg = "❌ No sitter available at the moment. Booking rejected.";
            $notify->bind_param("is", $parent_id, $msg);
            $notify->execute();

            $message = "❌ Booking rejected. No sitter available.";
        }
    } else {
        $message = "Invalid sitter ID.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Book Sitter | ChaguaSitter</title>
<style>
body {
    font-family: 'Poppins', sans-serif;
    background: #f7f7f7;
    margin: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}
.container {
    background: white;
    padding: 30px;
    border-radius: 10px;
    width: 400px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    text-align: center;
}
button {
    background: #ff7f50;
    border: none;
    padding: 10px 20px;
    color: white;
    border-radius: 6px;
    cursor: pointer;
}
button:hover {
    background: #ff5a1f;
}
.success { color: green; }
.error { color: red; }
</style>
</head>
<body>
<div class="container">
    <h2>Book a Sitter</h2>
    <form method="POST">
        <input type="number" name="sitter_id" placeholder="Enter Sitter ID" required><br>
        <input type="date" name="booking_date" required><br><br>
        <button type="submit" name="submit">Book Now</button>
    </form>

    <?php if ($message): ?>
        <p class="<?php echo (strpos($message, 'approved') !== false) ? 'success' : 'error'; ?>">
            <?php echo $message; ?>
        </p>
    <?php endif; ?>
</div>
<script src="script.js"></script>
</body>
</html>
