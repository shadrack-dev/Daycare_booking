<?php
session_start();
include 'db_connect.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Explore Sitters | ChaguaSitter</title>
<style>
body {
    margin: 0;
    font-family: "Poppins", sans-serif;
    background: #f9f9f9;
}

/* Header */
header {
    background: #ff6f00;
    color: white;
    padding: 20px;
    text-align: center;
}
header h1 { margin: 0; }
nav { margin-top: 10px; }
nav a {
    color: white;
    text-decoration: none;
    margin: 0 10px;
    font-weight: bold;
}
nav a:hover,
nav a.active { text-decoration: underline; }

/* Container */
.container {
    width: 90%;
    max-width: 1200px;
    margin: 30px auto;
}

h2 {
    text-align: center;
    color: #ff6f00;
    margin-bottom: 20px;
}

/* Filter box */
.filter-box {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 15px;
    background: white;
    padding: 15px;
    border-radius: 10px;
    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
    margin-bottom: 30px;
}
.filter-box select,
.filter-box input {
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 5px;
    min-width: 150px;
}
.filter-box button {
    background: #ff6f00;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    cursor: pointer;
    font-weight: bold;
}
.filter-box button:hover { background: #e55e00; }

/* Sitters grid */
.sitters-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
}

/* Sitter card */
.sitter-card {
    background: white;
    border-radius: 10px;
    padding: 15px;
    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
    text-align: center;
    transition: 0.3s;
}
.sitter-card:hover { transform: translateY(-5px); }
.sitter-card img {
    width: 100%;
    height: 180px;
    object-fit: cover;
    border-radius: 10px;
}
.sitter-card h3 { margin: 10px 0 5px; color: #333; }
.sitter-card p { margin: 5px 0; color: #555; }
.sitter-card a {
    display: inline-block;
    margin-top: 10px;
    padding: 10px 15px;
    background: #ff6f00;
    color: white;
    text-decoration: none;
    border-radius: 5px;
    transition: 0.3s;
}
.sitter-card a:hover { background: #e65c00; }

/* Footer */
footer {
    background: #333;
    color: white;
    text-align: center;
    padding: 15px;
    margin-top: 40px;
}
</style>
</head>
<body>

<header>
<h1>Explore Sitters</h1>
<nav>
    <a href="index.php">Home</a>
    <a href="explore_sitters.php" class="active">Explore Sitters</a>
    <a href="login.php">Login</a>
    <a href="register.php">Register</a>
</nav>
</header>

<div class="container">
<h2>Find the Perfect Sitter</h2>

<!-- Filter Section -->
<form class="filter-box" method="GET" action="">
    <input type="text" name="search" placeholder="Search sitter by name..." 
        value="<?php echo htmlspecialchars($_GET['search'] ?? ''); ?>">

    <?php
    $locations = ["Rongai","Kasarani","Embakasi","Westlands","Langata","Kilimani","Karen",
                  "Kangemi","Kibera","Gikambura","Zambezi","Syokimau","Njiru","Dandora",
                  "Utawala","Thika Road","Kileleshwa","Lavington","Muthaiga","Gigiri",
                  "Kahawa","Other"];
    $selectedLocation = $_GET['location'] ?? '';
    ?>
    <select name="location">
        <option value="">All Locations in Nairobi</option>
        <?php foreach($locations as $loc): ?>
            <option value="<?php echo $loc; ?>" <?php echo ($selectedLocation === $loc) ? 'selected' : ''; ?>>
                <?php echo $loc; ?>
            </option>
        <?php endforeach; ?>
    </select>

    <?php $selectedExp = $_GET['experience'] ?? ''; ?>
    <select name="experience">
        <option value="">All Experience Levels</option>
        <option value="1" <?php echo ($selectedExp === "1") ? 'selected' : ''; ?>>1+ years</option>
        <option value="3" <?php echo ($selectedExp === "3") ? 'selected' : ''; ?>>3+ years</option>
        <option value="5" <?php echo ($selectedExp === "5") ? 'selected' : ''; ?>>5+ years</option>
    </select>

    <button type="submit">Filter</button>
</form>

<!-- Sitters Grid -->
<div class="sitters-grid">
<?php
$where = [];
$params = [];
$types = "";

// Search by name
if (!empty($_GET['search'])) {
    $where[] = "u.fullname LIKE ?";
    $params[] = "%" . $_GET['search'] . "%";
    $types .= "s";
}

// Filter by location
if (!empty($_GET['location'])) {
    $where[] = "s.location = ?";
    $params[] = $_GET['location'];
    $types .= "s";
}

// Filter by experience
if (!empty($_GET['experience'])) {
    $where[] = "s.experience >= ?";
    $params[] = (int)$_GET['experience'];
    $types .= "i";
}

$sql = "SELECT s.*, u.fullname FROM sitters s JOIN users u ON s.user_id = u.id";
if (!empty($where)) $sql .= " WHERE " . implode(" AND ", $where);

$stmt = $conn->prepare($sql);
if($stmt === false) die("SQL Error: " . $conn->error);

// Bind parameters safely
if(!empty($params)) $stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $fullname = htmlspecialchars($row['fullname'] ?? 'No Name');
        $locationText = htmlspecialchars($row['location'] ?? 'Not specified');
        $experienceText = htmlspecialchars($row['experience'] ?? '0');
        $rate = htmlspecialchars($row['hourly_rate'] ?? '0.00');
        $profilePhoto = !empty($row['profile_photo']) ? htmlspecialchars($row['profile_photo']) : 'images/default_sitter.png';
        $sitter_id = $row['sitter_id'] ?? 0;

        echo "
        <div class='sitter-card'>
            <img src='$profilePhoto' alt='Sitter'>
            <h3>$fullname</h3>
            <p>Location: $locationText</p>
            <p>Experience: $experienceText years</p>
            <p>Rate: Ksh $rate/hr</p>
            <a href='book_now.php?sitter_id=$sitter_id'>Book Now</a>
        </div>
        ";
    }
} else {
    echo "<p style='text-align:center; width:100%;'>No sitters found matching your filters.</p>";
}
$stmt->close();
?>
</div>
</div>

<footer>
<p>&copy; <?php echo date('Y'); ?> ChaguaSitter. All rights reserved.</p>
</footer>
<script src="script.js"></script>
</body>
</html>
