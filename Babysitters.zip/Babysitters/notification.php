<?php
session_start();
include('db_connect.php');

// Ensure parent is logged in
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'parent') {
    header('Location: index.php');
    exit();
}

$parent_id = $_SESSION['user_id'];

// --- Mark notification as read ---
if (isset($_GET['mark_read'])) {
    $notif_id = intval($_GET['mark_read']);
    $stmt = $conn->prepare("UPDATE notifications SET is_ready = 1 WHERE notification_id = ? AND parent_id = ?");
    $stmt->bind_param("ii", $notif_id, $parent_id);
    $stmt->execute();
    header("Location: notification.php");
    exit();
}

// --- Fetch notifications ---
$stmt = $conn->prepare("SELECT * FROM notifications WHERE parent_id = ? ORDER BY created_at DESC");
$stmt->bind_param("i", $parent_id);
$stmt->execute();
$notifications = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Notifications | ChaguaSitter</title>
<style>
/* ===== Global Styles ===== */
body {
    font-family: 'Poppins', sans-serif;
    background: #f0f2f5;
    margin: 0;
    padding: 0;
}

.container {
    max-width: 800px;
    margin: 40px auto;
    padding: 0 20px;
}

h1 {
    color: #ff6f00;
    text-align: center;
    margin-bottom: 30px;
}

/* ===== Notification Card ===== */
.notification-card {
    background: #fff;
    padding: 20px 25px;
    margin-bottom: 15px;
    border-radius: 12px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    transition: transform 0.2s, box-shadow 0.2s;
    position: relative;
}

.notification-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 6px 16px rgba(0,0,0,0.12);
}

.notification-card.unread::before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    width: 6px;
    height: 100%;
    background: #ff6f00;
    border-radius: 12px 0 0 12px;
}

.notification-card p {
    margin: 0;
    font-size: 16px;
    color: #333;
    flex: 1;
}

.notification-card a {
    text-decoration: none;
    background: #27ae60;
    color: #fff;
    padding: 8px 14px;
    border-radius: 6px;
    font-size: 14px;
    font-weight: 500;
    transition: background 0.2s;
}

.notification-card a:hover {
    background: #219150;
}

.notification-card .read-label {
    color: #999;
    font-size: 14px;
    font-weight: 500;
}

/* ===== Empty state ===== */
.empty-state {
    text-align: center;
    font-size: 16px;
    color: #666;
    padding: 40px 0;
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.05);
}
</style>
</head>
<body>
<div class="container">
    <h1>Notifications</h1>

    <?php if (empty($notifications)) { ?>
        <div class="empty-state">No notifications yet.</div>
    <?php } else { ?>
        <?php foreach ($notifications as $notif) { ?>
            <div class="notification-card <?php echo $notif['is_ready'] ? '' : 'unread'; ?>">
                <p><?php echo htmlspecialchars($notif['message']); ?></p>
                <?php if (!$notif['is_ready']) { ?>
                    <a href="notification.php?mark_read=<?php echo $notif['notification_id']; ?>">Mark as Read</a>
                <?php } else { ?>
                    <span class="read-label">Read</span>
                <?php } ?>
            </div>
        <?php } ?>
    <?php } ?>
</div>
<script src="script.js"></script>
</body>
</html>
