<?php
session_start();
include 'db_connect.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Handle availability update
if (isset($_POST['update_availability'])) {
    $sitter_id = $_POST['sitter_id'];
    $new_status = $_POST['new_status'];

    $update_sql = "UPDATE sitters SET availability = ? WHERE sitter_id = ?";
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("si", $new_status, $sitter_id);
    $stmt->execute();
}

// Fetch all sitters
$sql = "SELECT sitter_id, full_name, email, phone, availability FROM sitters ORDER BY sitter_id DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manage Sitters Availability</title>
  <style>
    body {
      font-family: "Segoe UI", Arial, sans-serif;
      background: url('https://images.unsplash.com/photo-1601758125946-6ec2a0b03b4b?auto=format&fit=crop&w=1600&q=80') center/cover no-repeat;
      color: #333;
      padding: 60px;
    }
    .container {
      background: rgba(255, 255, 255, 0.95);
      padding: 40px;
      border-radius: 10px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.2);
      max-width: 950px;
      margin: auto;
    }
    h2 {
      text-align: center;
      color: #2c3e50;
      margin-bottom: 20px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 15px;
    }
    th, td {
      padding: 12px;
      border-bottom: 1px solid #ddd;
      text-align: center;
    }
    th {
      background-color: #f8f8f8;
      color: #333;
    }
    tr:hover {
      background-color: #f2f2f2;
    }
    .available {
      color: green;
      font-weight: bold;
    }
    .unavailable {
      color: red;
      font-weight: bold;
    }
    .update-btn {
      background: #007bff;
      color: white;
      border: none;
      padding: 6px 14px;
      border-radius: 6px;
      cursor: pointer;
      transition: 0.3s;
    }
    .update-btn:hover {
      background: #0056b3;
    }
    select {
      padding: 5px;
      border-radius: 4px;
      border: 1px solid #ccc;
    }
    a.back {
      display: inline-block;
      margin-top: 20px;
      text-decoration: none;
      color: white;
      background: #28a745;
      padding: 10px 20px;
      border-radius: 6px;
      transition: 0.3s;
    }
    a.back:hover {
      background: #218838;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>Manage Sitters Availability</h2>

    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Full Name</th>
          <th>Email</th>
          <th>Phone</th>
          <th>Current Status</th>
          <th>Change Status</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($result->num_rows > 0): ?>
          <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
              <td><?= htmlspecialchars($row['sitter_id']) ?></td>
              <td><?= htmlspecialchars($row['full_name']) ?></td>
              <td><?= htmlspecialchars($row['email']) ?></td>
              <td><?= htmlspecialchars($row['phone']) ?></td>
              <td class="<?= $row['availability'] === 'available' ? 'available' : 'unavailable' ?>">
                <?= ucfirst($row['availability']) ?>
              </td>
              <td>
                <form method="POST" style="display:inline;">
                  <input type="hidden" name="sitter_id" value="<?= $row['sitter_id'] ?>">
                  <select name="new_status">
                    <option value="available" <?= $row['availability'] == 'available' ? 'selected' : '' ?>>Available</option>
                    <option value="unavailable" <?= $row['availability'] == 'unavailable' ? 'selected' : '' ?>>Unavailable</option>
                  </select>
                  <button type="submit" name="update_availability" class="update-btn">Update</button>
                </form>
              </td>
            </tr>
          <?php endwhile; ?>
        <?php else: ?>
          <tr><td colspan="6">No sitters found</td></tr>
        <?php endif; ?>
      </tbody>
    </table>

    <a href="admin_dashboard.php" class="back">← Back to Dashboard</a>
  </div>
  <script src="script.js"></script>
</body>
</html>