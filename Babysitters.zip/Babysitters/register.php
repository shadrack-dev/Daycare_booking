<?php
session_start();
include 'db_connect.php';

$error = "";

// Handle registration
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = trim($_POST['fullname']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $role = $_POST['role'];

    // Validate passwords
    if ($password !== $confirm_password) {
        $error = "Passwords do not match!";
    } else {
        // Hash password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Check if email already exists
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $error = "Email already exists. Please login instead.";
        } else {
            // Insert new user
            $insert = $conn->prepare("INSERT INTO users (fullname, email, password, role) VALUES (?, ?, ?, ?)");
            $insert->bind_param("ssss", $fullname, $email, $hashedPassword, $role);

            if ($insert->execute()) {
                $user_id = $conn->insert_id;

                // If role is parent, create a parent record
                if ($role === 'parent') {
                    $conn->query("INSERT INTO parents (user_id, phone, address) VALUES ($user_id, '', '')");
                }

                // Redirect after successful registration
                header("Location: login.php");
                exit();
            } else {
                $error = "Registration failed. Please try again.";
            }
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Register | ChaguaSitter</title>
<style>
body {
    background: url('https://www.shutterstock.com/shutterstock/photos/2640547397/display_1500/stock-photo-african-daycare-centre-with-caregiver-2640547397.jpg') no-repeat center center/cover;
    font-family: 'Poppins', sans-serif;
    margin: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
}
.register-box {
    background: white;
    padding: 40px;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    width: 400px;
    text-align: center;
}
.register-box h2 {
    color: #ff6f00;
    margin-bottom: 20px;
}
.register-box input, 
.register-box select {
    width: 90%;
    padding: 10px;
    margin: 10px 0;
    border-radius: 6px;
    border: 1px solid #ccc;
}
.password-wrapper {
    position: relative;
    display: inline-block;
    width: 90%;
}
.password-wrapper input {
    width: 90%;
    padding-right: 25px;
}
.toggle-password {
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-50%);
    cursor: pointer;
    font-size: 16px;
    color: #555;
}
.register-box button {
    width: 90%;
    padding: 12px;
    background: #ff6f00;
    color: white;
    border: none;
    border-radius: 6px;
    font-weight: bold;
    cursor: pointer;
}
.register-box button:hover {
    background: #e65c00;
}
.error-message {
    color: red;
    margin: 10px 0;
}
a {
    color: #ff6f00;
    text-decoration: none;
}
a:hover {
    text-decoration: underline;
}
</style>
</head>
<body>
<div class="register-box">
    <h2>Create Account</h2>
    <?php if (!empty($error)): ?>
        <p class="error-message"><?php echo $error; ?></p>
    <?php endif; ?>

    <form method="POST">
        <input type="text" name="fullname" placeholder="Full Name" required>
        <input type="email" name="email" placeholder="Email Address" required>

        <div class="password-wrapper">
            <input type="password" name="password" id="password" placeholder="Password" required>
            <span class="toggle-password" onclick="togglePassword('password', this)">👁️</span>
        </div>

        <div class="password-wrapper">
            <input type="password" name="confirm_password" id="confirm_password" placeholder="Confirm Password" required>
            <span class="toggle-password" onclick="togglePassword('confirm_password', this)">👁️</span>
        </div>

        <select name="role" required>
            <option value="">Select Role</option>
            <option value="parent">Parent</option>
            <option value="sitter">Sitter</option>
        </select>

        <button type="submit">Register</button>
    </form>

    <p>Already have an account? <a href="login.php">Login</a></p>
</div>

<script>
function togglePassword(id, icon) {
    const input = document.getElementById(id);
    if (input.type === "password") {
        input.type = "text";
        icon.textContent = "🙈";
    } else {
        input.type = "password";
        icon.textContent = "👁️";
    }
}
</script>
<script src="script.js"></script>
</body>
</html>
