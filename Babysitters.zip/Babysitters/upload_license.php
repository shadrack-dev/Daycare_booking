<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'sitter') {
    header('Location: index.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch sitter ID
$stmt = $conn->prepare("SELECT sitter_id FROM sitters WHERE user_id = ?");
$stmt->bind_param('i', $user_id);
$stmt->execute();
$sitter = $stmt->get_result()->fetch_assoc();
if (!$sitter) die("Sitter record not found.");
$sitter_id = $sitter['sitter_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['license_file'])) {
    $file = $_FILES['license_file'];
    $allowed = ['pdf','jpg','jpeg','png'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

    if (in_array($ext, $allowed)) {
        $newName = uniqid() . '.' . $ext;
        $uploadDir = 'uploads/licenses/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

        if (move_uploaded_file($file['tmp_name'], $uploadDir . $newName)) {
            // Save to DB, mark as not verified
            $stmt = $conn->prepare("UPDATE sitters SET license_file=?, license_verified=0 WHERE sitter_id=?");
            $stmt->bind_param('si', $newName, $sitter_id);
            $stmt->execute();
            $success = "License uploaded successfully! Awaiting admin verification.";
        } else {
            $error = "Failed to upload license.";
        }
    } else {
        $error = "Invalid file type. Allowed: pdf, jpg, jpeg, png";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Upload License | ChaguaSitter</title>
<style>
body{font-family:'Poppins',sans-serif;background:#f8f8f8;margin:0;padding:0;}
.container{max-width:600px;margin:50px auto;background:#fff;padding:25px;border-radius:12px;box-shadow:0 5px 15px rgba(0,0,0,0.1);}
h2{text-align:center;color:#f68b1e;margin-bottom:25px;}
input[type=file]{width:100%;padding:10px;border-radius:6px;border:1px solid #ddd;}
button{margin-top:20px;background:#f68b1e;color:#fff;border:none;padding:12px 20px;border-radius:6px;width:100%;cursor:pointer;}
button:hover{background:#e67e1e;}
.success{background:#e0f7e9;padding:10px;border-left:5px solid green;margin-bottom:15px;border-radius:6px;color:#007c00;}
.error{background:#ffe0e0;padding:10px;border-left:5px solid red;margin-bottom:15px;border-radius:6px;color:#a10000;}
footer{text-align:center;color:#fff;background:#f68b1e;padding:12px;margin-top:40px;font-size:13px;}
</style>
</head>
<body>
<div class="container">
<h2>Upload Your License</h2>

<?php if(isset($success)) echo "<div class='success'>$success</div>"; ?>
<?php if(isset($error)) echo "<div class='error'>$error</div>"; ?>

<form method="POST" enctype="multipart/form-data">
    <input type="file" name="license_file" required>
    <button type="submit">Upload License</button>
</form>
</div>
<footer>© <?= date("Y") ?> ChaguaSitter. All rights reserved.</footer>
<script src="script.js"></script>
</body>
</html>
