<?php
session_start();
include('db_connect.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Privacy Policy | ChaguaSitter</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body {
      font-family: "Poppins", sans-serif;
      margin: 0;
      background-color: #f8f8f8;
      color: #333;
    }

    header {
      background-color: #ff6f00;
      color: white;
      text-align: center;
      padding: 40px 20px;
    }

    header h1 {
      margin: 0;
      font-size: 2rem;
      letter-spacing: 1px;
    }

    .container {
      width: 90%;
      max-width: 1000px;
      margin: 40px auto;
      background: #fff;
      padding: 40px;
      border-radius: 10px;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
      line-height: 1.7;
    }

    h2 {
      color: #ff6f00;
      margin-top: 30px;
    }

    p {
      font-size: 16px;
      margin-bottom: 15px;
    }

    ul {
      margin-left: 20px;
      list-style: disc;
    }

    a.back-link {
      display: inline-block;
      margin-top: 25px;
      color: #ff6f00;
      text-decoration: none;
      font-weight: 600;
    }

    a.back-link:hover {
      text-decoration: underline;
    }

    footer {
      background-color: #333;
      color: white;
      text-align: center;
      padding: 15px;
      margin-top: 50px;
    }

    footer p {
      margin: 0;
      font-size: 14px;
    }
  </style>
</head>

<body>

  <header>
    <h1>Privacy Policy</h1>
  </header>

  <div class="container">
    <p>At <strong>ChaguaSitter</strong>, your privacy is our top priority. We are committed to protecting your personal information and ensuring that your data is handled safely and responsibly.</p>

    <h2>1. Information We Collect</h2>
    <p>We collect the following types of information when you use our platform:</p>
    <ul>
      <li>Personal details (e.g., name, email, phone number)</li>
      <li>Booking and sitter preferences</li>
      <li>Communication records between parents and sitters</li>
      <li>Payment and transaction details</li>
    </ul>

    <h2>2. How We Use Your Information</h2>
    <p>Your data helps us improve and personalize your experience. Specifically, we use your information to:</p>
    <ul>
      <li>Match parents with reliable babysitters</li>
      <li>Facilitate secure bookings and communication</li>
      <li>Provide customer support and improve our services</li>
      <li>Comply with legal and safety requirements</li>
    </ul>

    <h2>3. Data Security</h2>
    <p>We implement strong security measures to protect your data from unauthorized access or misuse. Passwords are encrypted and sensitive information is stored securely.</p>

    <h2>4. Sharing of Information</h2>
    <p>We do <strong>not</strong> sell or rent your personal information. However, we may share data with:</p>
    <ul>
      <li>Trusted service providers (e.g., payment processors)</li>
      <li>Law enforcement when required by law</li>
    </ul>

    <h2>5. Your Rights</h2>
    <p>You have the right to access, update, or delete your personal information. If you wish to exercise these rights, please contact us via our support page.</p>

    <h2>6. Updates to This Policy</h2>
    <p>We may update this privacy policy from time to time. Any major changes will be communicated through the website.</p>

    <h2>7. Contact Us</h2>
    <p>If you have any questions about our privacy practices, please contact us at:</p>
    <p><strong>Email:</strong> support@chaguasitter.com</p>

    <a href="index.php" class="back-link">← Back to Home</a>
  </div>

  <footer>
    <p>&copy; <?php echo date('Y'); ?> ChaguaSitter. All rights reserved. </p>
  </footer>
  <script src="script.js"></script>
</body>
</html>

