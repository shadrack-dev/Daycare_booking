<?php
session_start();
include 'db_connect.php';

$error = "";
$message = "";

// Role-based dashboard mapping
$dashboard_pages = [
    'admin' => 'admin_dashboard.php',
    'sitter' => 'sitters_dashboard.php',
    'parent' => 'parent_dashboard.php'
];

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, password, role FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user['role'];

            if (isset($dashboard_pages[$user['role']])) {
                header("Location: " . $dashboard_pages[$user['role']]);
                exit;
            } else {
                $error = "❌ Unknown user role!";
            }
        } else {
            $error = "❌ Invalid Email or Password!";
        }
    } else {
        $error = "❌ Invalid Email or Password!";
    }
}

if (isset($_SESSION['user_id']) && isset($dashboard_pages[$_SESSION['role']])) {
    $message = "You are already logged in. <a href='" . $dashboard_pages[$_SESSION['role']] . "'>Go to your dashboard</a>.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login | ChaguaSitter</title>
<style>
/* ===== Global Styles ===== */
body {
    font-family: 'Poppins', sans-serif;
    margin: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    background: url('https://www.shutterstock.com/shutterstock/photos/2640547397/display_1500/stock-photo-african-daycare-centre-with-caregiver-2640547397.jpg') no-repeat center center/cover;
}

.login-box {
    background: rgba(255, 255, 255, 0.95);
    padding: 40px 35px;
    border-radius: 12px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.25);
    width: 360px;
    text-align: center;
}

.login-box h2 {
    color: #ff6f00;
    margin-bottom: 25px;
    font-size: 26px;
}

input[type="email"],
input[type="password"],
button {
    width: 100%;
    box-sizing: border-box;
}

input[type="email"],
input[type="password"] {
    padding: 12px 15px;
    margin: 10px 0;
    border-radius: 6px;
    border: 1px solid #ccc;
    font-size: 14px;
}

.password-wrapper {
    position: relative;
}

.password-wrapper input {
    padding-right: 40px;
}

.toggle-password {
    position: absolute;
    right: 12px;
    top: 50%;
    transform: translateY(-50%);
    cursor: pointer;
    font-size: 18px;
    color: #555;
}

button {
    padding: 12px 0;
    margin-top: 15px;
    border: none;
    border-radius: 8px;
    background-color: #ff6f00;
    color: white;
    font-weight: bold;
    font-size: 16px;
    cursor: pointer;
    transition: background 0.3s ease;
}

button:hover {
    background-color: #e65c00;
}

a {
    color: #ff6f00;
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}

.error {
    color: red;
    margin-top: 12px;
    font-size: 14px;
}

.success {
    color: green;
    margin-top: 12px;
    font-size: 14px;
}

.login-box p {
    margin-top: 12px;
    font-size: 14px;
}
</style>
</head>
<body>
<div class="login-box">
    <h2>Login</h2>
    <form method="POST" action="">
        <input type="email" name="email" placeholder="Enter Email" required>

        <div class="password-wrapper">
            <input type="password" name="password" id="password" placeholder="Enter Password" required>
            <span class="toggle-password" onclick="togglePassword('password', this)">👁️</span>
        </div>

        <button type="submit" name="login">Login</button>
    </form>

    <p><a href="forgot_password.php">Forgot Password?</a></p>

    <?php if ($error): ?>
        <p class="error"><?php echo $error; ?></p>
    <?php endif; ?>
    <?php if ($message): ?>
        <p class="success"><?php echo $message; ?></p>
    <?php endif; ?>

    <p>Don’t have an account? <a href="register.php">Register</a></p>
</div>

<script>
function togglePassword(id, icon) {
    const input = document.getElementById(id);
    if (input.type === "password") {
        input.type = "text";
        icon.textContent = "🙈";
    } else {
        input.type = "password";
        icon.textContent = "👁️";
    }
}
</script>
<script src="script.js"></script>
</body>
</html>
