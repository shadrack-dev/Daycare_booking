<?php
session_start();
include 'db_connect.php'; // connect to your database

// Ensure the user is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'sitter') {
    header("Location: index.php");
    exit();
}

$sitter_id = $_SESSION['user_id'];
$message = "";

// Handle approval or rejection
if (isset($_GET['action']) && isset($_GET['booking_id'])) {
    $booking_id = intval($_GET['booking_id']);
    $action = $_GET['action'];

    if ($action == 'approve') {
        $update = "UPDATE bookings SET status='approved' WHERE booking_id=$booking_id AND sitter_id=$sitter_id";
        $msg_text = "Booking approved successfully! ✅";
    } elseif ($action == 'reject') {
        $update = "UPDATE bookings SET status='rejected' WHERE booking_id=$booking_id AND sitter_id=$sitter_id";
        $msg_text = "Booking rejected ❌";
    }

    if (mysqli_query($conn, $update)) {
        $message = "<p class='success'>$msg_text</p>";
    } else {
        $message = "<p class='error'>Error: " . mysqli_error($conn) . "</p>";
    }
}

// Fetch sitter's bookings
$query = "SELECT b.booking_id, b.booking_date, b.start_time, b.end_time, b.status,
                 p.full_name AS parent_name, p.phone AS parent_phone
          FROM bookings b
          JOIN parents p ON b.parent_id = p.parent_id
          WHERE b.sitter_id = '$sitter_id'
          ORDER BY b.booking_date DESC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Approve Bookings | Chaguasitter</title>
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background-color: #f4f4f4;
      margin: 0;
      padding: 0;
    }
    header {
      background: #ff914d;
      color: white;
      padding: 15px 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    header a {
      color: white;
      text-decoration: none;
      margin-left: 15px;
      font-weight: 500;
    }
    .container {
      width: 90%;
      max-width: 900px;
      margin: 40px auto;
      background: white;
      padding: 20px 30px;
      border-radius: 10px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }
    h2 {
      text-align: center;
      color: #333;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }
    th, td {
      padding: 12px;
      border-bottom: 1px solid #ddd;
      text-align: center;
    }
    th {
      background-color: #ff914d;
      color: white;
    }
    tr:hover {
      background-color: #f1f1f1;
    }
    .btn {
      padding: 8px 14px;
      border-radius: 6px;
      text-decoration: none;
      font-weight: 600;
      transition: 0.3s;
    }
    .approve {
      background: #28a745;
      color: white;
    }
    .reject {
      background: #dc3545;
      color: white;
    }
    .approve:hover { background: #218838; }
    .reject:hover { background: #c82333; }
    .success { color: green; text-align: center; font-weight: bold; }
    .error { color: red; text-align: center; font-weight: bold; }
  </style>
</head>
<body>

<header>
  <h3>Chaguasitter</h3>
  <nav>
    <a href="index.php">🏠 Dashboard</a>
    <a href="approve_bookings.php">✅ Approve Bookings</a>
    <a href="profile.php">👤 Profile</a>
    <a href="logout.php">🚪 Logout</a>
  </nav>
</header>

<div class="container">
  <h2>Manage Booking Requests</h2>
  <?php echo $message; ?>

  <table>
    <tr>
      <th>#</th>
      <th>Parent</th>
      <th>Contact</th>
      <th>Date</th>
      <th>Time</th>
      <th>Status</th>
      <th>Action</th>
    </tr>
    <?php
    if (mysqli_num_rows($result) > 0) {
        $count = 1;
        while ($row = mysqli_fetch_assoc($result)) {
            echo "
            <tr>
              <td>{$count}</td>
              <td>{$row['parent_name']}</td>
              <td>{$row['parent_phone']}</td>
              <td>{$row['booking_date']}</td>
              <td>{$row['start_time']} - {$row['end_time']}</td>
              <td>{$row['status']}</td>
              <td>";
              if ($row['status'] == 'pending') {
                echo "<a href='approve_bookings.php?action=approve&booking_id={$row['booking_id']}' class='btn approve'>Approve</a>
                      <a href='approve_bookings.php?action=reject&booking_id={$row['booking_id']}' class='btn reject'>Reject</a>";
              } else {
                echo "<span style='color: gray;'>Processed</span>";
              }
            echo "</td></tr>";
            $count++;
        }
    } else {
        echo "<tr><td colspan='7'>No bookings available at the moment.</td></tr>";
    }
    ?>
  </table>
</div>
<script src="script.js"></script>
</body>
</html>
