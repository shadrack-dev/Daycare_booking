<?php
session_start();
include('db_connect.php');

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Fetch user data securely
$user_id = $_SESSION['user_id'];
$sql = "SELECT fullname, role FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

$fullname = htmlspecialchars($user['fullname']);
$role = htmlspecialchars($user['role']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Dashboard | ChaguaSitter</title>
  <link rel="stylesheet" href="style.css" />
  <style>
    body {
      font-family: "Poppins", sans-serif;
      margin: 0;
      background: url('https://images.unsplash.com/photo-1596464716121-6c2d54b8c2d5?auto=format&fit=crop&w=1600&q=80') center/cover no-repeat fixed;
      color: #333;
    }
    header {
      background: rgba(0, 0, 0, 0.6);
      color: white;
      padding: 15px 30px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
    }
    main {
      padding: 40px;
      background: rgba(255, 255, 255, 0.9);
      margin: 40px auto;
      border-radius: 15px;
      max-width: 1000px;
      box-shadow: 0 0 15px rgba(0,0,0,0.3);
    }
    h1, h2, h3 {
      color: #2c3e50;
    }
    a {
      text-decoration: none;
      color: #3498db;
      font-weight: bold;
      margin: 0 10px;
    }
    a:hover {
      text-decoration: underline;
    }
    .dashboard-links {
      margin-top: 20px;
      display: flex;
      flex-wrap: wrap;
      gap: 15px;
    }
    footer {
      text-align: center;
      background: rgba(0,0,0,0.7);
      color: white;
      padding: 10px;
      position: fixed;
      bottom: 0;
      width: 100%;
    }
    .role-badge {
      background: #3498db;
      color: white;
      padding: 5px 10px;
      border-radius: 8px;
      font-size: 14px;
    }
  </style>
</head>
<body>

<header>
  <h2>Welcome, <?= $fullname ?> 👋</h2>
  <div>
    <span class="role-badge"><?= ucfirst($role) ?></span>
    <a href="logout.php">Logout</a>
  </div>
</header>

<main>
  <?php if ($role === 'parent'): ?>
    <h1>Parent Dashboard</h1>
    <p>Explore sitters, book your preferred one, and manage your bookings.</p>
    <div class="dashboard-links">
      <a href="view_sitters.php">🧑‍🍼 View Sitters</a>
      <a href="my_bookings.php">📅 My Bookings</a>
      <a href="profile.php">👤 My Profile</a>
    </div>

  <?php elseif ($role === 'sitter'): ?>
    <h1>Sitter Dashboard</h1>
    <p>View assigned jobs, manage your availability, and grow your reputation.</p>
    <div class="dashboard-links">
      <a href="view_bookings.php">📋 View Assigned Jobs</a>
      <a href="update_availability.php">🕓 Update Availability</a>
      <a href="profile.php">👤 My Profile</a>
    </div>

  <?php elseif ($role === 'admin'): ?>
    <h1>Admin Dashboard</h1>
    <p>Manage the entire system — users, sitters, bookings, and reports.</p>
    <div class="dashboard-links">
      <a href="manage_parents.php">👨‍👩‍👧 Manage Parents</a>
      <a href="manage_sitters.php">🧑‍🍼 Manage Sitters</a>
      <a href="manage_bookings.php">📅 Manage Bookings</a>
      <a href="reports_reviews.php">📊 Reports & Reviews</a>
      <a href="system_settings.php">⚙️ System Settings</a>
    </div>
  <?php endif; ?>
</main>

<footer>
  &copy; <?= date("Y") ?> ChaguaSitter
</footer>
<script src="script.js"></script>
</body>
</html>

