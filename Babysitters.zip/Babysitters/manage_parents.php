<?php
session_start();
include('db_connect.php');

// Only allow admin
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
  header("Location: login.php");
  exit();
}

// Delete parent
if(isset($_GET['delete'])){
  $id = $_GET['delete'];
  mysqli_query($conn, "DELETE FROM users WHERE id='$id' AND role='parent'");
  header("Location: manage_parents.php");
  exit();
}

// Get all parents
$result = mysqli_query($conn, "SELECT * FROM users WHERE role='parent' ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage Parents | ChaguaSitter Admin</title>
<style>
  body { font-family: 'Poppins', sans-serif; background: #f6f6f6; margin: 0; }
  .container { width: 90%; margin: 40px auto; background: #fff; padding: 25px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
  h2 { color: #333; text-align: center; margin-bottom: 20px; }
  table { width: 100%; border-collapse: collapse; margin-top: 20px; }
  th, td { padding: 12px 15px; border-bottom: 1px solid #ddd; text-align: left; }
  th { background: #ff9900; color: white; }
  tr:hover { background: #fff3e0; }
  .actions a { margin-right: 10px; padding: 8px 12px; border-radius: 6px; text-decoration: none; font-size: 14px; }
  .edit { background: #007bff; color: white; }
  .delete { background: #dc3545; color: white; }
  .edit:hover { background: #0056b3; }
  .delete:hover { background: #b52b37; }
  .topbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; }
  .topbar a { text-decoration: none; color: #ff9900; font-weight: 600; }
  .search-box input { padding: 8px; width: 200px; border-radius: 6px; border: 1px solid #ccc; }
</style>
<script>
function confirmDelete(name){
  return confirm("Are you sure you want to delete parent " + name + "?");
}

function filterParents() {
  let filter = document.getElementById("searchInput").value.toLowerCase();
  let rows = document.querySelectorAll("tbody tr");
  rows.forEach(row => {
    let text = row.textContent.toLowerCase();
    row.style.display = text.includes(filter) ? "" : "none";
  });
}
</script>
</head>
<body>
  <div class="container">
    <div class="topbar">
      <h2>Manage Parents</h2>
      <a href="admin_dashboard.php">← Back to Dashboard</a>
    </div>

    <div class="search-box">
      <input type="text" id="searchInput" onkeyup="filterParents()" placeholder="Search parent...">
    </div>

    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>Full Name</th>
          <th>Email</th>
          <th>Phone</th>
          <th>Location</th>
          <th>Date Joined</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php 
        $count = 1;
        while($row = mysqli_fetch_assoc($result)): ?>
        <tr>
          <td><?php echo $count++; ?></td>
          <td><?php echo htmlspecialchars($row['fullname']); ?></td>
          <td><?php echo htmlspecialchars($row['email']); ?></td>
          <td><?php echo htmlspecialchars($row['phone']); ?></td>
          <td><?php echo htmlspecialchars($row['location']); ?></td>
          <td><?php echo date('d M Y', strtotime($row['created_at'])); ?></td>
          <td class="actions">
            <a href="view_parent.php?id=<?php echo $row['id']; ?>" class="edit">View</a>
            <a href="?delete=<?php echo $row['id']; ?>" class="delete" onclick="return confirmDelete('<?php echo $row['fullname']; ?>')">Delete</a>
          </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
<script src="script.js"></script>
</body>
</html>