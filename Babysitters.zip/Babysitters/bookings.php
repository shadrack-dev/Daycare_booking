<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'parent') {
    header('Location: index.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch parent info
$stmt = $conn->prepare("SELECT parent_id, num_children FROM parents WHERE user_id = ?");
$stmt->bind_param('i', $user_id);
$stmt->execute();
$parent = $stmt->get_result()->fetch_assoc();
if (!$parent) die("Parent record not found.");

$parent_id = $parent['parent_id'];
$parent_daily_limit = 3;
$system_daily_limit = 20;
$today = date('Y-m-d');

// Count today's bookings for parent
$stmt = $conn->prepare("SELECT COUNT(*) AS c FROM bookings WHERE parent_id=? AND DATE(booking_date)=?");
$stmt->bind_param('is', $parent_id, $today);
$stmt->execute();
$parent_count = $stmt->get_result()->fetch_assoc()['c'];

// Count today's bookings system-wide
$stmt = $conn->prepare("SELECT COUNT(*) AS c FROM bookings WHERE DATE(booking_date)=?");
$stmt->bind_param('s', $today);
$stmt->execute();
$system_count = $stmt->get_result()->fetch_assoc()['c'];

// Calculate remaining slots
$parent_slots_left = max(0, $parent_daily_limit - $parent_count);
$system_slots_left = max(0, $system_daily_limit - $system_count);
$slots_left = min($parent_slots_left, $system_slots_left);

// Progress percentage for system-wide bookings
$progress_percentage = round(($system_count / $system_daily_limit) * 100);

$limit_reached = $slots_left <= 0;
$message = $system_slots_left <= 0 
    ? "System booking limit reached. Please try again tomorrow."
    : ($parent_slots_left <= 0 ? "You have reached your booking limit for today." : "");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add Booking | ChaguaSitter</title>
<style>
  body { font-family: 'Poppins', sans-serif; background-color: #f8f8f8; margin: 0; padding: 0; }
  header { background-color: #f68b1e; color: #fff; padding: 15px 40px; display: flex; justify-content: space-between; align-items: center; }
  header h2 { margin: 0; font-size: 22px; }
  header nav a { color: #fff; text-decoration: none; margin-left: 15px; }
  .container { max-width: 700px; margin: 40px auto; background: #fff; padding: 25px; border-radius: 12px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
  h2 { color: #f68b1e; text-align: center; margin-bottom: 25px; }
  .notice { background: #fff3e0; border-left: 5px solid #f68b1e; padding: 12px 15px; border-radius: 6px; margin-bottom: 20px; color: #444; font-size: 15px; text-align: center; }
  .slots { background: #e0f7fa; border-left: 5px solid #00acc1; padding: 10px 15px; border-radius: 6px; margin-bottom: 20px; font-size: 15px; text-align: center; font-weight: 600; color: #007c91; }
  .progress-container { background-color: #eee; border-radius: 10px; overflow: hidden; margin-bottom: 20px; height: 20px; }
  .progress-bar { height: 100%; background-color: #f68b1e; text-align: center; color: #fff; line-height: 20px; font-size: 12px; }
  form label { display: block; margin-top: 15px; margin-bottom: 5px; font-weight: 600; }
  form select, form input[type=date], form input[type=number] { width: 100%; padding: 10px; border-radius: 6px; border: 1px solid #ddd; font-size: 14px; }
  .btn { margin-top: 20px; background-color: #f68b1e; color: #fff; border: none; padding: 12px 20px; border-radius: 6px; cursor: pointer; font-size: 15px; width: 100%; }
  .btn:hover { background-color: #e67e1e; }
  .btn.disabled { background-color: #ccc; cursor: not-allowed; }
  footer { background-color: #f68b1e; color: #fff; text-align: center; padding: 12px; margin-top: 40px; font-size: 13px; }
</style>
</head>
<body>

<header>
  <h2>🧡 ChaguaSitter | Add Booking</h2>
  <nav><a href="my_bookings.php">My Bookings</a></nav>
</header>

<div class="container">
  <h2>New Booking</h2>

  <?php if (!$limit_reached): ?>
    <!-- Slots left -->
    <div class="slots">Available Slots Today: <?= $slots_left ?></div>

    <!-- Progress bar -->
    <div class="progress-container">
      <div class="progress-bar" style="width: <?= $progress_percentage ?>%;"><?= $progress_percentage ?>%</div>
    </div>
  <?php endif; ?>

  <!-- Limit reached notice -->
  <?php if ($limit_reached): ?>
    <div class="notice"><?= $message ?></div>
    <button class="btn disabled" disabled>Booking Disabled</button>
  <?php else: ?>
    <form method="POST" action="process_booking.php">
      <label for="sitter_id">Select Sitter:</label>
      <select name="sitter_id" id="sitter_id" required>
        <option value="">-- Choose Sitter --</option>
        <?php
        $sitters = $conn->query("SELECT s.sitter_id, u.fullname FROM sitters s JOIN users u ON s.user_id=u.id ORDER BY u.fullname");
        while ($s = $sitters->fetch_assoc()) {
            echo "<option value='{$s['sitter_id']}'>" . htmlspecialchars($s['fullname']) . "</option>";
        }
        ?>
      </select>

      <label for="booking_date">Booking Date:</label>
      <input type="date" name="booking_date" id="booking_date" required min="<?= date('Y-m-d') ?>">

      <label for="duration">Duration (hours):</label>
      <input type="number" name="duration" id="duration" required min="1" max="12">

      <button type="submit" class="btn">Confirm Booking</button>
    </form>
  <?php endif; ?>
</div>

<footer>
  © <?= date("Y") ?> ChaguaSitter. All rights reserved.
</footer>
<script src="script.js"></script>
</body>
</html>
