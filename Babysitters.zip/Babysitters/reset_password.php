<?php
session_start();
include('db_connect.php');

if(!isset($_SESSION['reset_email'])) {
    header("Location: forgot_password.php");
    exit();
}

$error = "";
$message = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $password = $_POST['password'];
    $confirm = $_POST['confirm_password'];

    if ($password !== $confirm) {
        $error = "Passwords do not match!";
    } else {
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE users SET password=? WHERE email=?");
        $stmt->bind_param("ss", $hashed, $_SESSION['reset_email']);
        if($stmt->execute()){
            $message = "Password updated successfully!";
            unset($_SESSION['reset_email']);
        } else {
            $error = "Failed to reset password!";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Reset Password | ChaguaSitter</title>
<style>
body { font-family:'Poppins',sans-serif; display:flex; justify-content:center; align-items:center; height:100vh; background:#f0f0f0; margin:0;}
.reset-box { background:white; padding:30px; border-radius:12px; width:350px; text-align:center; box-shadow:0 4px 10px rgba(0,0,0,0.2);}
input { width:90%; padding:10px; margin:10px 0; border-radius:6px; border:1px solid #ccc;}
button { padding:12px; background:#ff7f50; color:white; border:none; border-radius:8px; cursor:pointer;}
button:hover{ background:#ff5a1f;}
.error { color:red; }
.success { color:green; }
</style>
</head>
<body>
<div class="reset-box">
<h2>Reset Password</h2>
<form method="POST" action="">
<input type="password" name="password" placeholder="New Password" required><br>
<input type="password" name="confirm_password" placeholder="Confirm Password" required><br>
<button type="submit">Reset</button>
</form>
<?php
if($error) echo "<p class='error'>$error</p>";
if($message) echo "<p class='success'>$message</p>";
?>
</div>
<script src="script.js"></script>
</body>
</html>
