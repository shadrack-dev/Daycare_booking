<?php
session_start();
include 'db_connect.php';

// Check if the sitter is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Get sitter info
$sql = "SELECT sitter_id, availability FROM sitters WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$sitter = $result->fetch_assoc();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_status = $_POST['availability'];

    $update_sql = "UPDATE sitters SET availability = ? WHERE user_id = ?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param("si", $new_status, $user_id);

    if ($update_stmt->execute()) {
        $message = "Availability updated successfully!";
        $sitter['availability'] = $new_status;
    } else {
        $message = "Error updating availability.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Update Availability</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: url('https://images.unsplash.com/photo-1601758173925-78a6b0efc0b0?auto=format&fit=crop&w=1600&q=80') center/cover no-repeat;
      color: #333;
      text-align: center;
      padding: 60px;
    }
    .container {
      background: rgba(255, 255, 255, 0.9);
      display: inline-block;
      padding: 40px;
      border-radius: 10px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.2);
    }
    select, button {
      padding: 10px;
      font-size: 16px;
      margin-top: 10px;
    }
    .success {
      color: green;
      font-weight: bold;
    }
    .error {
      color: red;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>Update Availability</h2>
    <?php if (isset($message)) echo "<p class='".(strpos($message, 'success') !== false ? 'success' : 'error')."'>$message</p>"; ?>
    <form method="POST">
      <label for="availability">Select Your Status:</label><br>
      <select name="availability" id="availability">
        <option value="available" <?= $sitter['availability'] === 'available' ? 'selected' : '' ?>>Available</option>
        <option value="unavailable" <?= $sitter['availability'] === 'unavailable' ? 'selected' : '' ?>>Unavailable</option>
      </select><br>
      <button type="submit">Update</button>
    </form>
    <p><a href="sitter_dashboard.php">← Back to Dashboard</a></p>
  </div>
  <script src="script.js"></script>
</body>
</html>