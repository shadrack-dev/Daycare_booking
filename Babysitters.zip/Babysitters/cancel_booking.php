<?php
session_start();
include 'db_connect.php';


// Ensure the user is logged in and is a parent
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'parent') {
    header("Location: login.php");
    exit();
}

if (isset($_GET['id'])) {
    $booking_id = intval($_GET['id']);
    $user_id = $_SESSION['user_id'];

    // Check if the booking belongs to the logged-in parent
    $checkQuery = "
        SELECT b.booking_id 
        FROM bookings b
        JOIN parents p ON b.parent_id = p.parent_id
        WHERE b.booking_id = ? AND p.user_id = ?
    ";
    $stmt = $conn->prepare($checkQuery);
    $stmt->bind_param("ii", $booking_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Cancel the booking
        $updateQuery = "UPDATE bookings SET status = 'cancelled' WHERE booking_id = ?";
        $stmt2 = $conn->prepare($updateQuery);
        $stmt2->bind_param("i", $booking_id);
        if ($stmt2->execute()) {
            echo "<script>alert('Booking cancelled successfully!'); window.location.href='parent_dashboard.php';</script>";
        } else {
            echo "<script>alert('Error cancelling booking. Try again.'); window.location.href='parent_dashboard.php';</script>";
        }
    } else {
        echo "<script>alert('You are not authorized to cancel this booking.'); window.location.href='parent_dashboard.php';</script>";
    }
} else {
    header("Location: parent_Dashboard.php");
    exit();
}
?>
