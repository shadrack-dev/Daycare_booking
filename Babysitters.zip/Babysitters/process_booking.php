<?php
session_start();
include 'db_connect.php';

// Ensure parent is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'parent') {
    header('Location: index.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch parent ID
$stmt = $conn->prepare("SELECT parent_id FROM parents WHERE user_id = ?");
$stmt->bind_param('i', $user_id);
$stmt->execute();
$parent = $stmt->get_result()->fetch_assoc();
if (!$parent) {
    $_SESSION['error'] = "Parent not found.";
    header("Location: my_bookings.php");
    exit();
}

$parent_id = $parent['parent_id'];
$today = date('Y-m-d');
$parent_daily_limit = 3;
$system_daily_limit = 20;

// Check today's bookings for parent
$stmt = $conn->prepare("SELECT COUNT(*) AS c FROM bookings WHERE parent_id=? AND DATE(booking_date)=?");
$stmt->bind_param('is', $parent_id, $today);
$stmt->execute();
$pCount = $stmt->get_result()->fetch_assoc()['c'];

// Check today's bookings system-wide
$stmt = $conn->prepare("SELECT COUNT(*) AS t FROM bookings WHERE DATE(booking_date)=?");
$stmt->bind_param('s', $today);
$stmt->execute();
$sCount = $stmt->get_result()->fetch_assoc()['t'];

// If limit reached, redirect with error
if ($pCount >= $parent_daily_limit || $sCount >= $system_daily_limit) {
    $_SESSION['error'] = "Booking limit reached. Try again tomorrow.";
    header("Location: my_bookings.php");
    exit();
}

// Collect form data
$sitter_id = intval($_POST['sitter_id']);
$booking_date = $_POST['booking_date'];
$duration = intval($_POST['duration']);
$child_conditions = $_POST['child_conditions'] ?? '';

// Insert booking with child_conditions
$stmt = $conn->prepare("INSERT INTO bookings (parent_id, sitter_id, booking_date, duration, status, child_conditions) VALUES (?, ?, ?, ?, 'pending', ?)");
$stmt->bind_param('iisss', $parent_id, $sitter_id, $booking_date, $duration, $child_conditions);

if ($stmt->execute()) {
    $_SESSION['success'] = "Booking created successfully!";
} else {
    $_SESSION['error'] = "Error creating booking: " . $conn->error;
}

header("Location: my_bookings.php");
exit();
?>
