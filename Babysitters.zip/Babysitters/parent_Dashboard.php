<?php
session_start();
include 'db_connect.php';

// Ensure the user is logged in as a parent
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'parent') {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch parent details
$query = "SELECT p.*, u.fullname, u.email 
          FROM parents p 
          JOIN users u ON p.user_id = u.id 
          WHERE p.user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$parent = $result->fetch_assoc();

// If no parent record exists
if (!$parent) {
    $parent = [
        'fullname' => 'Parent',
        'email' => 'Not available',
        'phone' => 'Not available',
        'address' => 'Not available'
    ];
}

// Fetch parent bookings
$bookingsQuery = "SELECT b.*, s.sitter_id, u.fullname AS sitter_name 
                  FROM bookings b 
                  JOIN sitters s ON b.sitter_id = s.sitter_id 
                  JOIN users u ON s.user_id = u.id 
                  WHERE b.parent_id = (SELECT parent_id FROM parents WHERE user_id = ?)";
$stmt2 = $conn->prepare($bookingsQuery);
$stmt2->bind_param("i", $user_id);
$stmt2->execute();
$bookings = $stmt2->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Parent Dashboard | ChaguaSitter</title>
  <style>
    body {
      font-family: "Poppins", sans-serif;
      background: url('https://www.shutterstock.com/shutterstock/photos/2640547397/display_1500/stock-photo-african-daycare-centre-with-caregiver-2640547397.jpg') no-repeat center center/cover;
      margin: 0;
      color: #333;
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }

    /* ===== Navbar ===== */
    header.navbar {
      background-color: #2b6777;
      color: white;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 15px 25px;
      position: relative;
      z-index: 1000;
    }

    .brand {
      font-size: 1.5em;
      font-weight: bold;
      display: flex;
      align-items: center;
      gap: 8px;
    }

    /* Left menu */
    .nav-left {
      display: flex;
      align-items: center;
      gap: 15px;
    }

    .nav-left a {
      color: white;
      text-decoration: none;
      font-weight: 500;
      transition: color 0.3s;
    }

    .nav-left a:hover {
      color: #52ab98;
    }

    /* Right menu */
    .nav-right {
      display: flex;
      align-items: center;
      gap: 15px;
    }

    .nav-right a {
      color: white;
      text-decoration: none;
      font-weight: 500;
      transition: color 0.3s;
    }

    .nav-right a:hover {
      color: #52ab98;
    }

    /* Hamburger menu */
    .menu-toggle {
      display: none;
      flex-direction: column;
      cursor: pointer;
      margin-right: 10px;
    }

    .menu-toggle div {
      width: 25px;
      height: 3px;
      background-color: white;
      margin: 4px 0;
      transition: 0.4s;
    }

    /* Mobile dropdown */
    .nav-left {
      transition: all 0.3s ease-in-out;
    }

    /* ===== Dashboard ===== */
    .dashboard-container {
      flex: 1;
      display: flex;
      flex-direction: row;
      padding: 30px;
    }

    .dashboard-content {
      flex: 1;
      background: rgba(255,255,255,0.92);
      padding: 30px;
      border-radius: 15px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.2);
    }

    h3 {
      color: #2b6777;
      border-bottom: 2px solid #52ab98;
      padding-bottom: 5px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 15px;
    }

    table, th, td {
      border: 1px solid #ccc;
      text-align: left;
    }

    th {
      background-color: #2b6777;
      color: white;
      padding: 10px;
    }

    td { padding: 8px; }

    .btn {
      background: #52ab98;
      border: none;
      padding: 7px 12px;
      border-radius: 5px;
      color: white;
      cursor: pointer;
      text-decoration: none;
    }

    .btn:hover {
      background: #3f8b79;
    }

    footer {
      background-color: #2b6777;
      color: white;
      text-align: center;
      padding: 15px;
      margin-top: auto;
    }

    /* ===== Responsive ===== */
    @media (max-width: 768px) {
      .menu-toggle {
        display: flex;
      }

      .nav-left {
        display: none;
        flex-direction: column;
        background-color: #2b6777;
        position: absolute;
        top: 60px;
        left: 0;
        width: 100%;
        padding: 10px 0;
      }

      .nav-left.active {
        display: flex;
      }

      .nav-left a {
        text-align: center;
        padding: 10px;
        width: 100%;
      }

      .nav-right {
        display: flex;
        gap: 10px;
      }

      .dashboard-container {
        flex-direction: column;
        padding: 15px;
      }

      .dashboard-content {
        padding: 20px;
      }
    }
  </style>
</head>
<body>

<!-- ===== NAVBAR ===== -->
<header class="navbar">
  <div style="display: flex; align-items: center; gap: 15px;">
    <div class="menu-toggle" onclick="toggleMenu()">
      <div></div>
      <div></div>
      <div></div>
    </div>

    <span class="brand"> ChaguaSitter</span>
  </div>

  <nav class="nav-left" id="navLeft">
    <a href="parent_dashboard.php">Dashboard</a>
    <a href="add_booking.php">Add Booking</a>
    <a href="feedback.html">Feedback</a>
    <a href="help.php">Help</a>
    <a href="privacy.php">Privacy</a>
  </nav>

  <div class="nav-right">
    <a href="profile.php">Profile</a>
    <a href="logout.php">Logout</a>
  </div>
</header>

<!-- ===== DASHBOARD CONTENT ===== -->
<div class="dashboard-container">
  <main class="dashboard-content">
    <h3>Welcome, <?php echo htmlspecialchars($parent['fullname']); ?> </h3>

    <p><strong>Email:</strong> <?php echo htmlspecialchars($parent['email']); ?></p>
    <p><strong>Phone:</strong> <?php echo htmlspecialchars($parent['phone']); ?></p>
    <p><strong>Address:</strong> <?php echo htmlspecialchars($parent['address']); ?></p>

    <h3>My Bookings</h3>

    <?php if ($bookings->num_rows > 0) { ?>
      <table>
        <tr>
          <th>Sitter Name</th>
          <th>Booking Date</th>
          <th>Start Time</th>
          <th>End Time</th>
          <th>Status</th>
          <th>Action</th>
        </tr>
        <?php while ($row = $bookings->fetch_assoc()) { ?>
          <tr>
            <td><?php echo htmlspecialchars($row['sitter_name']); ?></td>
            <td><?php echo htmlspecialchars($row['booking_date']); ?></td>
            <td><?php echo htmlspecialchars($row['start_time']); ?></td>
            <td><?php echo htmlspecialchars($row['end_time']); ?></td>
            <td><?php echo ucfirst(htmlspecialchars($row['status'])); ?></td>
            <td>
              <?php if ($row['status'] == 'completed') { ?>
                <a class="btn" href="review.php?booking_id=<?php echo $row['booking_id']; ?>">Review</a>
              <?php } else { ?>
                <a class="btn" href="cancel_booking.php?id=<?php echo $row['booking_id']; ?>">Cancel</a>
              <?php } ?>
            </td>
          </tr>
        <?php } ?>
      </table>
    <?php } else { ?>
      <p style="color: #2b6777;">You have no bookings yet. 
        <a href="add_booking.php" style="color:#52ab98;">Click here to add one.</a>
      </p>
    <?php } ?>
  </main>
</div>

<!-- ===== FOOTER ===== -->
<footer>
  <p>© <?php echo date("Y"); ?> ChaguaSitter. All Rights Reserved.</p>
</footer>

<!-- ===== SCRIPT ===== -->
<script>
function toggleMenu() {
  document.getElementById("navLeft").classList.toggle("active");
}
</script>
<script src="script.js"></script>
</body>
</html>
