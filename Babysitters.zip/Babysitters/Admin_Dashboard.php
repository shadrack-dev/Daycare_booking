<?php
session_start();
include('db_connect.php');

// Check if admin is logged in
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] != 'admin') {
    header('Location: index.php');
    exit;
}

// Fetch system data
$parents = mysqli_query($conn, "SELECT * FROM parents");
$sitters = mysqli_query($conn, "SELECT * FROM sitters");
$bookings = mysqli_query($conn, "SELECT * FROM bookings");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard | ChaguaSitter</title>
  <link rel="stylesheet" href="styles.css">
  <script src="script.js" defer></script>
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      margin: 0;
      background: url('https://www.shutterstock.com/shutterstock/photos/2640547397/display_1500/stock-photo-african-daycare-centre-with-caregiver-2640547397.jpg') no-repeat center center/cover;
      background-attachment: fixed;
    }
    header {
      background: rgba(255,255,255,0.9);
      padding: 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    h1 { color: #e67e22; }
    nav a {
      margin: 0 10px;
      text-decoration: none;
      color: #333;
    }
    nav a:hover { color: #e67e22; }
    .container {
      background: rgba(255,255,255,0.9);
      margin: 40px auto;
      padding: 25px;
      width: 90%;
      border-radius: 20px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin: 20px 0;
    }
    th, td {
      padding: 12px;
      border: 1px solid #ccc;
    }
    th {
      background: #e67e22;
      color: white;
    }
    section {
      margin-bottom: 40px;
    }
  </style>
</head>
<body>

<header>
  <h1>ChaguaSitter Admin Panel</h1>
  <nav>
    <a href="index.php">Home</a>
    <a href="manage_parents.php">Manage Parents</a>
    <a href="manage_sitters.php">Manage Sitters</a>
    <a href="manage_bookings.php">Manage Bookings</a>
    <a href="reports_reviews.php">Reports</a>
    <a href="logout.php">Logout</a>
  </nav>
</header>

<div class="container">
  <section>
    <h2> Parents List</h2>
    <table>
      <tr><th>ID</th><th>Name</th><th>Email</th><th>Location</th></tr>
      <?php while($p = mysqli_fetch_assoc($parents)) { ?>
      <tr>
        <td><?php echo $p['id']; ?></td>
        <td><?php echo $p['name']; ?></td>
        <td><?php echo $p['email']; ?></td>
        <td><?php echo $p['location']; ?></td>
      </tr>
      <?php } ?>
    </table>
  </section>

  <section>
    <h2>👩‍🍼 Sitters List</h2>
    <table>
      <tr><th>ID</th><th>Name</th><th>Email</th><th>Experience</th></tr>
      <?php while($s = mysqli_fetch_assoc($sitters)) { ?>
      <tr>
        <td><?php echo $s['id']; ?></td>
        <td><?php echo $s['name']; ?></td>
        <td><?php echo $s['email']; ?></td>
        <td><?php echo $s['experience']; ?> yrs</td>
      </tr>
      <?php } ?>
    </table>
  </section>

  <section>
    <h2>📅 Bookings Overview</h2>
    <table>
      <tr><th>ID</th><th>Parent</th><th>Sitter</th><th>Date</th><th>Status</th></tr>
      <?php while($b = mysqli_fetch_assoc($bookings)) { ?>
      <tr>
        <td><?php echo $b['id']; ?></td>
        <td><?php echo $b['parent_name']; ?></td>
        <td><?php echo $b['sitter_name']; ?></td>
        <td><?php echo $b['booking_date']; ?></td>
        <td><?php echo ucfirst($b['status']); ?></td>
      </tr>
      <?php } ?>
    </table>
  </section>
</div>
<script src="script.js"></script>
</body>
</html>
