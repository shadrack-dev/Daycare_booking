<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: index.php');
    exit();
}

// Handle verification
if(isset($_GET['verify'])) {
    $sitter_id = intval($_GET['verify']);
    $stmt = $conn->prepare("UPDATE sitters SET license_verified=1 WHERE sitter_id=?");
    $stmt->bind_param('i', $sitter_id);
    $stmt->execute();
}

// Fetch all sitters with uploaded licenses
$query = "SELECT s.sitter_id, u.fullname, s.license_file, s.license_verified FROM sitters s JOIN users u ON s.user_id=u.id WHERE s.license_file IS NOT NULL ORDER BY u.fullname";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin Verify Licenses | ChaguaSitter</title>
<style>
body{font-family:'Poppins',sans-serif;background:#f8f8f8;margin:0;padding:0;}
.container{max-width:900px;margin:40px auto;background:#fff;padding:25px;border-radius:12px;box-shadow:0 5px 15px rgba(0,0,0,0.1);}
h2{text-align:center;color:#f68b1e;margin-bottom:25px;}
table{width:100%;border-collapse:collapse;}
th,td{padding:12px;border:1px solid #ddd;}
th{background:#f68b1e;color:#fff;}
tr:nth-child(even){background:#f9f9f9;}
.btn{padding:6px 12px;background:#f68b1e;color:#fff;border:none;border-radius:5px;text-decoration:none;}
.btn:hover{background:#e67e1e;}
.verified{color:green;font-weight:bold;}
.not-verified{color:red;font-weight:bold;}
footer{text-align:center;color:#fff;background:#f68b1e;padding:12px;margin-top:40px;font-size:13px;}
</style>
</head>
<body>
<div class="container">
<h2>Admin - Verify Sitter Licenses</h2>
<table>
<tr><th>Name</th><th>License</th><th>Status</th><th>Action</th></tr>
<?php
if($result->num_rows>0){
    while($row=$result->fetch_assoc()){
        $status = $row['license_verified'] ? "<span class='verified'>Verified ✅</span>" : "<span class='not-verified'>Not Verified ❌</span>";
        $license_link = "<a href='uploads/licenses/{$row['license_file']}' target='_blank' class='btn'>View</a>";
        $action = $row['license_verified'] ? '' : "<a href='?verify={$row['sitter_id']}' class='btn'>Verify</a>";
        echo "<tr>
            <td>".htmlspecialchars($row['fullname'])."</td>
            <td>$license_link</td>
            <td>$status</td>
            <td>$action</td>
        </tr>";
    }
} else {
    echo "<tr><td colspan='4' style='text-align:center;'>No licenses uploaded</td></tr>";
}
?>
</table>
</div>
<footer>© <?= date("Y") ?> ChaguaSitter. All rights reserved.</footer>
</body>
</html>
