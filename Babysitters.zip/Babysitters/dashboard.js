// === Dashboard Enhancements Script ===

// 1️ Greeting + Clock
function showGreetingAndClock() {
  const greetingElement = document.getElementById("greeting");
  const clockElement = document.getElementById("clock");

  function updateTime() {
    const now = new Date();
    const hours = now.getHours();
    const minutes = String(now.getMinutes()).padStart(2, "0");
    const seconds = String(now.getSeconds()).padStart(2, "0");
    const timeString = `${hours}:${minutes}:${seconds}`;
    clockElement.textContent = " " + timeString;

    let greeting;
    if (hours < 12) greeting = "Good Morning ";
    else if (hours < 18) greeting = "Good Afternoon ";
    else greeting = "Good Evening ";

    greetingElement.textContent = greeting;
  }

  updateTime();
  setInterval(updateTime, 1000);
}

// 2️ Notifications
function showNotification(message, type = "info") {
  const notification = document.createElement("div");
  notification.textContent = message;
  notification.className = `notification ${type}`;
  document.body.appendChild(notification);

  setTimeout(() => {
    notification.remove();
  }, 3000);
}

// 3️ Logout confirmation
function confirmLogout() {
  return confirm("Are you sure you want to log out?");
}

// 4️ Booking Filter Example
function filterBookings() {
  const filter = document.getElementById("statusFilter").value;
  const rows = document.querySelectorAll("#bookingTable tbody tr");

  rows.forEach(row => {
    const status = row.querySelector(".status").textContent.trim().toLowerCase();
    if (filter === "all" || filter === status) {
      row.style.display = "";
    } else {
      row.style.display = "none";
    }
  });
}

// 5️ Auto initialize greeting and clock
window.onload = showGreetingAndClock;
