<?php
session_start();
include 'db_connect.php';

// Ensure sitter is logged in
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'sitter') {
    header('Location: sitter_auth.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch sitter info
$stmt = $conn->prepare("SELECT * FROM sitters WHERE user_id = ?");
$stmt->bind_param('i', $user_id);
$stmt->execute();
$sitter = $stmt->get_result()->fetch_assoc();

// Check if sitter exists
if (!$sitter) {
    die("Sitter not found.");
}

// Fetch additional photos safely
$photos = $conn->query("SELECT * FROM sitters_photos WHERE sitter_id = ".$sitter['sitter_id'])->fetch_all(MYSQLI_ASSOC);

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $phone = $_POST['phone'] ?? '';
    $experience = $_POST['experience'] ?? 0;
    $bio = $_POST['bio'] ?? '';
    $daily_rate = $_POST['daily_rate'] ?? 0;
    $availability = $_POST['availability'] ?? 'available';
    $location = $_POST['location'] ?? '';

    $allowedExt = ['jpg','jpeg','png','gif'];

    // Update profile photo
    if (isset($_FILES['profile_photo']) && $_FILES['profile_photo']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['profile_photo']['tmp_name'];
        $fileName = $_FILES['profile_photo']['name'];
        $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

        if (in_array($fileExt, $allowedExt)) {
            if(!empty($sitter['profile_photo']) && file_exists($sitter['profile_photo'])){
                unlink($sitter['profile_photo']);
            }
            $newFileName = 'uploads/' . uniqid() . '.' . $fileExt;
            move_uploaded_file($fileTmpPath, $newFileName);
            $sitter['profile_photo'] = $newFileName;
        }
    }

    // Update sitter table
    $update = $conn->prepare("UPDATE sitters SET phone=?, experience=?, bio=?, daily_rate=?, availability=?, location=?, profile_photo=? WHERE user_id=?");
    $update->bind_param('sisdsssi', $phone, $experience, $bio, $hourly_rate, $availability, $location, $sitter['profile_photo'], $user_id);
    $update->execute();

    // Upload additional photos
    if (!empty($_FILES['additional_photos']['tmp_name'])) {
        foreach ($_FILES['additional_photos']['tmp_name'] as $key => $tmp_name) {
            if ($_FILES['additional_photos']['error'][$key] === UPLOAD_ERR_OK) {
                $fileExt = strtolower(pathinfo($_FILES['additional_photos']['name'][$key], PATHINFO_EXTENSION));
                if (in_array($fileExt, $allowedExt)) {
                    $newFileName = 'uploads/' . uniqid() . '.' . $fileExt;
                    move_uploaded_file($tmp_name, $newFileName);
                    $stmtInsert = $conn->prepare("INSERT INTO sitter_photos (sitter_id, photo_path) VALUES (?, ?)");
                    $stmtInsert->bind_param('is', $sitter['sitter_id'], $newFileName);
                    $stmtInsert->execute();
                }
            }
        }
    }

    echo "<script>alert('Profile updated successfully!'); window.location.href='sitters_dashboard.php';</script>";
    exit();
}

// Delete additional photo
if (isset($_GET['delete_photo'])) {
    $photo_id = intval($_GET['delete_photo']);
    $photoData = $conn->query("SELECT photo_path FROM sitter_photos WHERE id=$photo_id")->fetch_assoc();
    if ($photoData && file_exists($photoData['photo_path'])) {
        unlink($photoData['photo_path']);
    }
    $conn->query("DELETE FROM sitter_photos WHERE id=$photo_id");
    header("Location: edit_rate.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Profile | ChaguaSitter</title>
<style>
body { font-family: 'Poppins', sans-serif; background: #f0f2f5; margin:0; padding:0; }
.container { max-width: 900px; margin:50px auto; background:#fff; padding:25px; border-radius:12px; box-shadow:0 5px 15px rgba(0,0,0,0.1); }
h2 { text-align:center; color:#ff6f00; margin-bottom:25px; }
label { display:block; font-weight:600; margin-bottom:5px; }
input, textarea, select { width:100%; padding:10px; margin-bottom:15px; border-radius:6px; border:1px solid #ccc; font-size:14px; }
textarea { min-height:100px; resize:vertical; }
.profile-photo { width:130px; height:130px; border-radius:50%; object-fit:cover; border:3px solid #ff6f00; display:block; margin-bottom:10px; }
.additional-photos { display:flex; flex-wrap:wrap; gap:10px; margin-bottom:15px; }
.additional-photos div { position:relative; }
.additional-photos img { width:100px; height:100px; object-fit:cover; border-radius:8px; border:2px solid #ff6f00; }
.delete-btn { position:absolute; top:2px; right:2px; background:#c0392b; color:#fff; border:none; padding:3px 6px; border-radius:50%; font-size:12px; cursor:pointer; }
.delete-btn:hover { background:#a93226; }
.btn { background:#ff6f00; color:#fff; padding:10px 18px; border-radius:6px; font-weight:bold; text-decoration:none; cursor:pointer; margin-top:10px; }
.btn:hover { background:#e65c00; }
.btn.secondary { background:#555; }
.btn.secondary:hover { background:#333; }
</style>
</head>
<body>
<div class="container">
<h2>Edit Your Profile</h2>
<form method="POST" enctype="multipart/form-data">

    <label>Main Profile Photo</label>
    <img src="<?php echo !empty($sitter['profile_photo']) ? $sitter['profile_photo'] : 'images/default_sitter.png'; ?>" class="profile-photo">
    <input type="file" name="profile_photo" accept="image/*">

    <label>Additional Photos</label>
    <div class="additional-photos">
        <?php foreach($photos as $p): ?>
            <div>
                <img src="<?php echo $p['photo_path']; ?>" alt="">
                <a href="?delete_photo=<?php echo $p['id']; ?>" class="delete-btn" onclick="return confirm('Remove this photo?')">×</a>
            </div>
        <?php endforeach; ?>
    </div>
    <input type="file" name="additional_photos[]" accept="image/*" multiple>

    <label>Phone</label>
    <input type="text" name="phone" value="<?php echo htmlspecialchars($sitter['phone'] ?? ''); ?>" required>

    <label>Experience (years)</label>
    <input type="number" name="experience" value="<?php echo htmlspecialchars($sitter['experience'] ?? 0); ?>" required>

    <label>Hourly Rate (Ksh)</label>
    <input type="number" name="hourly_rate" step="0.01" value="<?php echo htmlspecialchars($sitter['hourly_rate'] ?? 0); ?>" required>

    <label>Availability</label>
    <select name="availability" required>
        <option value="available" <?php echo (($sitter['availability'] ?? '') === 'available') ? 'selected' : ''; ?>>Available</option>
        <option value="unavailable" <?php echo (($sitter['availability'] ?? '') === 'unavailable') ? 'selected' : ''; ?>>Unavailable</option>
    </select>

    <label>Location</label>
    <input type="text" name="location" value="<?php echo htmlspecialchars($sitter['location'] ?? ''); ?>" required>

    <label>Bio</label>
    <textarea name="bio" placeholder="Tell parents about your experience..."><?php echo htmlspecialchars($sitter['bio'] ?? ''); ?></textarea>

    <div style="text-align:center;">
        <button type="submit" class="btn">Save Profile</button>
        <a href="sitters_dashboard.php" class="btn secondary">Cancel</a>
    </div>
</form>
</div>
<script src="script.js"></script>
</body>
</html>
