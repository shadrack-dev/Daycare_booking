<?php
session_start();
include('db_connect.php');

// Ensure only admin can access
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Fetch reviews with sitter and parent names
$sql = "
    SELECT r.review_id, r.rating, r.comment, r.created_at,
           up.fullname AS parent_name,
           us.fullname AS sitter_name
    FROM reviews r
    JOIN bookings b ON r.booking_id = b.booking_id
    JOIN parents p ON b.parent_id = p.parent_id
    JOIN sitters s ON b.sitter_id = s.sitter_id
    JOIN users up ON p.user_id = up.id
    JOIN users us ON s.user_id = us.id
    ORDER BY r.created_at DESC
";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin | Manage Reviews</title>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            background: #f9f9f9;
            color: #333;
        }

        header {
            background: #ff6f00;
            color: white;
            padding: 20px;
            text-align: center;
        }

        header h1 {
            margin: 0;
        }

        .container {
            width: 90%;
            max-width: 1000px;
            margin: 30px auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }

        table th, table td {
            padding: 12px 15px;
            border: 1px solid #ddd;
            text-align: left;
        }

        table th {
            background-color: #ff6f00;
            color: white;
        }

        table tr:nth-child(even) {
            background-color: #f4f4f4;
        }

        .back-link {
            display: inline-block;
            margin-top: 15px;
            text-decoration: none;
            color: #ff6f00;
            font-weight: bold;
        }

        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<header>
    <h1>Manage Reviews</h1>
</header>

<div class="container">
    <h2>All Reviews</h2>
    <?php if ($result && mysqli_num_rows($result) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Parent Name</th>
                    <th>Sitter Name</th>
                    <th>Rating</th>
                    <th>Comment</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['parent_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['sitter_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['rating']); ?></td>
                        <td><?php echo htmlspecialchars($row['comment']); ?></td>
                        <td><?php echo date("d M Y, H:i", strtotime($row['created_at'])); ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No reviews available.</p>
    <?php endif; ?>

    <a href="admin_dashboard.php" class="back-link">← Back to Dashboard</a>
</div>
<?php
session_start();
include('db_connect.php');

// Ensure only admin can access
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Fetch reviews with sitter and parent names
$sql = "
    SELECT r.review_id, r.rating, r.comment, r.created_at,
           up.fullname AS parent_name,
           us.fullname AS sitter_name
    FROM reviews r
    JOIN bookings b ON r.booking_id = b.booking_id
    JOIN parents p ON b.parent_id = p.parent_id
    JOIN sitters s ON b.sitter_id = s.sitter_id
    JOIN users up ON p.user_id = up.id
    JOIN users us ON s.user_id = us.id
    ORDER BY r.created_at DESC
";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin | Manage Reviews</title>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            background: #f9f9f9;
            color: #333;
        }

        header {
            background: #ff6f00;
            color: white;
            padding: 20px;
            text-align: center;
        }

        header h1 {
            margin: 0;
        }

        .container {
            width: 90%;
            max-width: 1000px;
            margin: 30px auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }

        table th, table td {
            padding: 12px 15px;
            border: 1px solid #ddd;
            text-align: left;
        }

        table th {
            background-color: #ff6f00;
            color: white;
        }

        table tr:nth-child(even) {
            background-color: #f4f4f4;
        }

        .back-link {
            display: inline-block;
            margin-top: 15px;
            text-decoration: none;
            color: #ff6f00;
            font-weight: bold;
        }

        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<header>
    <h1>Manage Reviews</h1>
</header>

<div class="container">
    <h2>All Reviews</h2>
    <?php if ($result && mysqli_num_rows($result) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Parent Name</th>
                    <th>Sitter Name</th>
                    <th>Rating</th>
                    <th>Comment</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['parent_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['sitter_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['rating']); ?></td>
                        <td><?php echo htmlspecialchars($row['comment']); ?></td>
                        <td><?php echo date("d M Y, H:i", strtotime($row['created_at'])); ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No reviews available.</p>
    <?php endif; ?>

    <a href="Admin_Dashboard.php" class="back-link">← Back to Dashboard</a>
</div>
<script src="script.js"></script>
</body>
</html>
