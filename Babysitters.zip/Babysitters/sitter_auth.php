<?php
session_start();
include('db_connect.php');

$error = "";
$message = "";

// --- Handle Registration ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
    $fullname = trim($_POST['fullname']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "⚠️ Please enter a valid email address!";
    } elseif (strlen($password) < 6) {
        $error = "⚠️ Password must be at least 6 characters!";
    } else {
        $check = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $check->bind_param("s", $email);
        $check->execute();
        $res = $check->get_result();

        if ($res->num_rows > 0) {
            $error = "⚠️ This email is already registered!";
        } else {
            $role = 'sitter';
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (fullname, email, password, role) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $fullname, $email, $hashed_password, $role);
            $stmt->execute();

            $user_id = $conn->insert_id;
            $insert_sitter = $conn->prepare("INSERT INTO sitters (user_id, availability) VALUES (?, 'available')");
            $insert_sitter->bind_param("i", $user_id);
            $insert_sitter->execute();

            $message = "🎉 Account created successfully! You can now login.";
        }
    }
}

// --- Handle Login ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? AND role = 'sitter'");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user['role'];
            header("Location: sitters_Dashboard.php");
            exit();
        } else {
            $error = "❌ Incorrect password!";
        }
    } else {
        $error = "❌ No account found with that email!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ChaguaSitter | Sitters Portal</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
<style>
/* ====== Reset & Base ====== */
* { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Poppins', sans-serif; }
body { background: #f0f2f5; display: flex; justify-content: center; align-items: center; min-height: 100vh; }

/* ====== Card Container ====== */
.auth-container {
    width: 400px;
    background: #fff;
    border-radius: 16px;
    overflow: hidden;
    box-shadow: 0 16px 40px rgba(0,0,0,0.12);
}

/* ====== Tabs ====== */
.tabs {
    display: flex;
    background: #ff6f00;
}
.tab {
    flex: 1;
    padding: 15px;
    text-align: center;
    font-weight: 600;
    color: #fff;
    cursor: pointer;
    transition: 0.3s;
}
.tab.active { background: #ff8c42; }

/* ====== Form Wrapper ====== */
form {
    display: none;
    flex-direction: column;
    padding: 30px;
    gap: 15px;
}
form.active { display: flex; }

/* ====== Inputs ====== */
input {
    width: 100%;
    padding: 12px 15px;
    border-radius: 8px;
    border: 1px solid #ccc;
    outline: none;
    font-size: 15px;
    transition: 0.3s;
}
input:focus { border-color: #ff6f00; }

/* ====== Password Toggle ====== */
.password-wrapper {
    position: relative;
}
.password-wrapper input { padding-right: 40px; }
.toggle-password {
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-50%);
    cursor: pointer;
    color: #888;
}
.toggle-password:hover { color: #ff6f00; }

/* ====== Buttons ====== */
button {
    width: 100%;
    padding: 12px;
    background: #ff6f00;
    color: #fff;
    border: none;
    border-radius: 8px;
    font-size: 16px;
    cursor: pointer;
    transition: 0.3s;
}
button:hover { background: #e55c00; }

/* ====== Messages ====== */
.error { color: #dc3545; font-weight: 500; text-align: center; margin-top: 10px; }
.success { color: #28a745; font-weight: 500; text-align: center; margin-top: 10px; }

/* ====== Animations ====== */
@keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
}

/* ====== Responsive ====== */
@media(max-width: 480px) {
    .auth-container { width: 90%; }
    .tab { font-size: 14px; padding: 12px; }
}
</style>
</head>
<body>

<div class="auth-container">
    <div class="tabs">
        <div class="tab active" id="loginTab">Login</div>
        <div class="tab" id="registerTab">Register</div>
    </div>

    <!-- Login Form -->
    <form method="POST" id="loginForm" class="active">
        <div class="password-wrapper">
            <input type="email" name="email" placeholder="Email Address" required>
        </div>
        <div class="password-wrapper">
            <input type="password" name="password" id="login_pass" placeholder="Password" required>
            <span class="toggle-password" onclick="togglePassword('login_pass', this)">👁️</span>
        </div>
        <button type="submit" name="login">Login</button>
    </form>

    <!-- Register Form -->
    <form method="POST" id="registerForm">
        <input type="text" name="fullname" placeholder="Full Name" required>
        <input type="email" name="email" placeholder="Email Address" required>
        <div class="password-wrapper">
            <input type="password" name="password" id="reg_pass" placeholder="Password" required>
            <span class="toggle-password" onclick="togglePassword('reg_pass', this)">👁️</span>
        </div>
        <button type="submit" name="register">Register</button>
    </form>

    <?php
    if(!empty($error)) echo "<p class='error'>$error</p>";
    if(!empty($message)) echo "<p class='success'>$message</p>";
    ?>
</div>

<script>
// ====== Tab Switching ======
const loginTab = document.getElementById('loginTab');
const registerTab = document.getElementById('registerTab');
const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');

loginTab.addEventListener('click', () => {
    loginTab.classList.add('active');
    registerTab.classList.remove('active');
    loginForm.classList.add('active');
    registerForm.classList.remove('active');
});
registerTab.addEventListener('click', () => {
    registerTab.classList.add('active');
    loginTab.classList.remove('active');
    registerForm.classList.add('active');
    loginForm.classList.remove('active');
});

// ====== Password Toggle ======
function togglePassword(id, icon) {
    const input = document.getElementById(id);
    if(input.type === "password") {
        input.type = "text";
        icon.textContent = "🙈";
    } else {
        input.type = "password";
        icon.textContent = "👁️";
    }
}
</script>
<script src="script.js"></script>
</body>
</html>
