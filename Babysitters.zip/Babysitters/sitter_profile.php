<?php
session_start();
include('db_connect.php');

// Ensure sitter is logged in
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'sitter') {
    header('Location: sitters_auth.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch sitter info along with email
$query = "SELECT s.*, u.email 
          FROM sitters s 
          JOIN users u ON s.user_id = u.id 
          WHERE s.user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('i', $user_id);
$stmt->execute();
$result = $stmt->get_result();
$sitter = $result->fetch_assoc() ?? [];
$stmt->close();

// Set default values to avoid undefined errors
$sitter['location'] = $sitter['location'] ?: 'Not specified';
$sitter['phone'] = $sitter['phone'] ?: 'Not specified';
$sitter['experience'] = $sitter['experience'] ?: 0;
$sitter['hourly_rate'] = $sitter['hourly_rate'] ?: '0.00';
$sitter['availability'] = $sitter['availability'] ?: 'Not specified';
$sitter['bio'] = $sitter['bio'] ?: 'No bio provided';
$sitter['profile_photo'] = $sitter['profile_photo'] ?: 'images/default_sitter.png';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sitter Profile | ChaguaSitter</title>
<style>
body {
    margin: 0;
    font-family: "Poppins", sans-serif;
    background: #f0f2f5;
}

header {
    background: #ff6f00;
    color: white;
    padding: 18px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

header h1 { margin: 0; font-size: 22px; }

header .profile-actions a {
    color: white;
    text-decoration: none;
    margin-left: 15px;
    font-weight: bold;
}
header .profile-actions a:hover { text-decoration: underline; }

.container {
    max-width: 750px;
    margin: 30px auto;
    background: #fff;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 6px 15px rgba(0,0,0,0.1);
}

h2 {
    color: #ff6f00;
    text-align: center;
    margin-bottom: 20px;
}

/* Profile picture */
.profile-photo {
    display: block;
    margin: 0 auto 20px;
    width: 140px;
    height: 140px;
    border-radius: 50%;
    object-fit: cover;
    border: 3px solid #ff6f00;
}

.profile-info p {
    font-size: 16px;
    margin: 10px 0;
}
.profile-info p span {
    font-weight: bold;
    color: #555;
}

.profile-buttons {
    margin-top: 25px;
    text-align: center;
}
.profile-buttons a {
    display: inline-block;
    margin: 5px 10px;
    padding: 10px 20px;
    background: #ff6f00;
    color: white;
    text-decoration: none;
    border-radius: 6px;
    font-weight: bold;
    transition: 0.3s;
}
.profile-buttons a:hover { background: #e65c00; }

footer {
    text-align: center;
    padding: 15px;
    background-color: #333;
    color: white;
    margin-top: 40px;
    font-size: 12px;
}

/* Responsive */
@media (max-width: 600px) {
    .container { margin: 20px; padding: 20px; }
    header { font-size: 20px; }
    .profile-buttons a { padding: 8px 15px; font-size: 14px; }
}
</style>
</head>
<body>

<header>
    <h1>My Profile</h1>
    <div class="profile-actions">
        <a href="edit_profile.php">Edit Profile</a>
        <a href="logout.php">Logout</a>
    </div>
</header>

<div class="container">
    <h2>Welcome, <?php echo htmlspecialchars($sitter['email']); ?></h2>
    <img src="<?php echo htmlspecialchars($sitter['profile_photo']); ?>" alt="Profile Photo" class="profile-photo">

    <div class="profile-info">
        <p><span>Email:</span> <?php echo htmlspecialchars($sitter['email']); ?></p>
        <p><span>Phone:</span> <?php echo htmlspecialchars($sitter['phone']); ?></p>
        <p><span>Experience:</span> <?php echo htmlspecialchars($sitter['experience']); ?> years</p>
        <p><span>Hourly Rate:</span> Ksh <?php echo htmlspecialchars($sitter['hourly_rate']); ?></p>
        <p><span>Availability:</span> <?php echo htmlspecialchars(ucfirst($sitter['availability'])); ?></p>
        <p><span>Location:</span> <?php echo htmlspecialchars($sitter['location']); ?></p>
        <p><span>Bio:</span><br /><?php echo nl2br(htmlspecialchars($sitter['bio'])); ?></p>
    </div>

    <div class="profile-buttons">
        <a href="edit_profile.php">Edit Profile</a>
        <a href="view_bookings.php">View Bookings</a>
    </div>
</div>

<footer>
    &copy; <?php echo date('Y'); ?> ChaguaSitter. All rights reserved.
</footer>
<script src="script.js"></script>
</body>
</html>
