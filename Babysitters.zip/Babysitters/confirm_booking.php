<?php
session_start();
include 'db_connect.php';
// Redirect if no sitters in cart
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    header("Location: booking_cart.php");
    exit();
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html?message=Please login to confirm your booking");
    exit();
}

$user_id = $_SESSION['user_id'];

// Get parent ID
$parentQuery = $conn->prepare("SELECT parent_id FROM parents WHERE user_id = ?");
$parentQuery->bind_param("i", $user_id);
$parentQuery->execute();
$parentResult = $parentQuery->get_result();
$parent = $parentResult->fetch_assoc();

if (!$parent) {
    die("Error: Only parents can make bookings.");
}

$parent_id = $parent['parent_id'];

// Handle booking submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $date = $_POST['booking_date'];
    $start = $_POST['start_time'];
    $end = $_POST['end_time'];

    foreach ($_SESSION['cart'] as $sitter_id) {
        $insert = $conn->prepare("INSERT INTO bookings (parent_id, sitter_id, booking_date, start_time, end_time, status) VALUES (?, ?, ?, ?, ?, 'pending')");
        $insert->bind_param("iisss", $parent_id, $sitter_id, $date, $start, $end);
        $insert->execute();
    }

    unset($_SESSION['cart']); // clear cart
    echo "<script>alert('Booking confirmed successfully!'); window.location='parent_dashboard.php';</script>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirm Booking | ChaguaSitter</title>
    <style>
        body {
            font-family: "Poppins", sans-serif;
            background: url('https://images.unsplash.com/photo-1602016753163-3b8c2d4c9a60?auto=format&fit=crop&w=1500&q=60') center/cover no-repeat;
            margin: 0;
            padding: 0;
            color: #333;
        }

        .container {
            width: 90%;
            max-width: 600px;
            background: rgba(255,255,255,0.95);
            padding: 30px;
            margin: 80px auto;
            border-radius: 12px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
        }

        h1 {
            text-align: center;
            color: #ff6f00;
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
            display: block;
            margin: 10px 0 5px;
        }

        input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 8px;
            margin-bottom: 15px;
            font-size: 15px;
        }

        button {
            width: 100%;
            padding: 12px;
            background: #ff6f00;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
        }

        button:hover {
            background: #e65c00;
        }

        a {
            display: block;
            text-align: center;
            margin-top: 15px;
            color: #333;
            text-decoration: none;
        }

        a:hover {
            color: #ff6f00;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Confirm Booking</h1>
    <form method="POST">
        <label for="booking_date">Booking Date:</label>
        <input type="date" name="booking_date" required>

        <label for="start_time">Start Time:</label>
        <input type="time" name="start_time" required>

        <label for="end_time">End Time:</label>
        <input type="time" name="end_time" required>

        <button type="submit">Confirm Booking</button>
    </form>

    <a href="booking_cart.php">← Back to Cart</a>
</div>
<script src="script.js"></script>
</body>
</html>
